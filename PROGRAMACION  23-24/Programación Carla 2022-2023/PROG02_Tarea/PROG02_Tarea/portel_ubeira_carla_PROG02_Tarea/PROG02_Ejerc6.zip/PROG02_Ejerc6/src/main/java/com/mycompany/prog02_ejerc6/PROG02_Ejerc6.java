/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc6;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc6 {

    public static void main(String[] args) {
        enum Razas{Mastín, Terrier, Bulldog, Pekinés, Caniche, Galgo}; //creamos un tipo enumerado con los siguientes valores
        Razas var1 = Razas.Mastín; //creamos una variable var1 y le asignamos un valor
        Razas var2 = Razas.Bulldog; //creamos una variable var2 y le asignamos un valor       
        System.out.println("Las razas " +var1 +" y " +var2 +(var1 == var2?" son iguales.":" no son iguales.")); //comparamos ambos valores de la variable y si son iguales es true (son iguales)
        //si no son iguales son false (no son iguales)
        System.out.println("La posición de " +var1 +" en el enumerando es " +var1.ordinal());
        System.out.println("La posición de " +var2 +" en el enumerando es " +var2.ordinal());
        System.out.println("Los valores de la raza son:");
        for(Razas d: Razas.values()){ //Razas.values() devuelve un array que contiene todos los valores de Razas
            System.out.print("- " +d.toString()+"\n"); //ordenamos que se visualice sus valores
        }//cerramos llaves 
    } //cerramos llaves de main
} //cerramos llaves de clase
