/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc10;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc10 {

    public static void main(String[] args) {
        System.out.println("------- Conversiones entre enteros y coma flotante -------");
        float x = 4.5f;
        float y = 3.0f;
        int i = 2;
        int j;
        j = (int) (x * i);
        System.out.println("Producto de int por float: j= i*x = " +j);
        double dx = 2.0d;
        double dz;
        dz = (float) (dx * y);
        System.out.println("Producto de float por double: dz=dx * y = " +j);
        System.out.println("");
        System.out.println("------- Operaciones con byte -------");
        byte bx = 5;
        byte by = 2;
        byte bz = (byte) (bx - by);
        System.out.println("byte: " +bx +" - " +by +" = " +bz);
        bx = -128;
        by = 1;
        bz = (byte)(bx - by);
        System.out.println("byte " +bx +" - " +by +" = " +bz);
        int entero = (bx - by); //variable intermedia de tipo entero para la conversión de tipos
        System.out.println("(int)( " +bx +" - " +by + ") = " +entero);
        System.out.println("");
        System.out.println("------- Operaciones con short -------");
        short sx = 5;
        short sy = 2;
        short sz = (short) (sx - sy);
        short sx2 = (short) (sx * 2);
        short sy2 = (short) (sx % sy);
        System.out.println("Short: " +sx2 +" - " +sy2 +" = " +sz);
        sx = 32767;
        sy = 1;
        sz = (short) (sx + sy);
        System.out.println("Short: " +sx +" - " +sy +" = " +sz);
        System.out.println("------- Operaciones con char -------");
        char cx = '\u000F';
        char cy = '\u0001';
        int z = (char) (cx - cy);//los caracteres pueden ser considerados como números enteros sin signo
        System.out.println("char: - = " +z);
        z = ((int) cx) - 1;
        String cxh = "0x000F";
        System.out.println("char (" +cxh +") - 1 = " +z);
        cx = '\uFFFF';
        z = cx;
        System.out.println("(int)( )= "+z);
        sx = (short) cx; 
        System.out.println("(short)( )= "+sx);
        sx = -32768;
        cx = (char) sx;
        z = (int) sx;
        sx = (short) cx; 
        System.out.println(+z +" short-char-int = " +-z);
        sx = -1;
        cx = (char) sx; 
        z = (int) cx; 
        System.out.println(+sx +" short-char-int = " +z);
    }
}
