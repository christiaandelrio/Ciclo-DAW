/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc1;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc1 { //declaración de clase

    
    public static void main(String[] args) { //método main
        final short VAL_MAX = 5000; 
        //es una variable de tipo constante (no modificable) 
        //que entra dentro del rango de short, entre -32,768 a 32,767
        boolean carnetConducir = true;
        //es una variable con dos valores posible, true o false
        byte mesAño = 10;
        //variable de tipo cadena y formato numérico
        String nombreApellidos = "Carla Portela Ubeira";
        //Variable de tipo cadena, texto
        enum Sexo {V, M};
        //tipo enumerado, cuyos valores sólo pueden ser hombre o mujer
        Sexo genero = Sexo.M; //creamos una variable y le asignamos un valor
        long miliseg = 1639872000000L; 
        //52 años x 365 días x 24 horas x 60 minutos x 60 segundos x 1000 milisegundos
        float saldoCuenta = 14544.45f; //variable en coma flotante de simple precisión
        int kms = 602860000; 
        //visualización de las variables sin utilizar printIn
        System.out.print("\nValor máximo no modificable: " +VAL_MAX);
        System.out.print("\nEl nuevo trabajador tiene carnet de conducir: " +carnetConducir);
        System.out.print("\nMes del año: " +mesAño);
        System.out.print("\nNombre y apellidos: " +nombreApellidos);
        System.out.print("\nSexo: " +genero);
        System.out.print("\nMilisegundos transcurridos desde el 01/01/1970 hasta nuestros días: " +miliseg);
        System.out.print("\nSaldo de una cuenta bancaria: " +saldoCuenta);
        System.out.print("\nDistancia en kms desde la Tierra a Júpiter: " +kms);
    } //se cierran llaves de main
} //se cierran llaves de clase

