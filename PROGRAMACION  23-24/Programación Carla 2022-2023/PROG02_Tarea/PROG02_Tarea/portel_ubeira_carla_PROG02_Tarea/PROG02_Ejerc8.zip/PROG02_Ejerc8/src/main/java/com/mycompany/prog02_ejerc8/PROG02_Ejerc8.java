/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc8;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc8 {

    public static void main(String[] args) {
        short numAlumProg=20; //se establecen las variable de tipo short ya que el resultado será de tipo real y no entero
        short numAlumED=30;
        short numAlumDB=10;
        float totalAlum = numAlumProg + numAlumED + numAlumDB;
        float porcentajeProg;//a pesar de que el resultado es de tipo real y no entero la conversión de short a float es automática
        float porcentajeED;
        float porcentajeDB;
            System.out.println("El porcentaje de alumnos matriculados en cada uno de los módulos es:");
            if(totalAlum != 0){ //se establece la condición y si se cumple se realizan las siguientes operaciones
            porcentajeProg = numAlumProg / totalAlum *100; //operación a realizar
            porcentajeProg = Math.round(porcentajeProg * 10) / 10f; //para que solo tenga un decimal multiplicamos el resultado 10^numero_decimales_finales 
            //y lo dividimos por ese mismo número
            System.out.printf("- Módulo de Programación: %.1f",porcentajeProg); //mensaje que se muestra con el valor
            System.out.print("%");
            porcentajeED = numAlumED / totalAlum *100; //operación a realizar
            porcentajeED = Math.round(porcentajeED *10) / 10f;
            System.out.printf("\n- Módulo de Entornos de Desarrollo: %.1f", porcentajeED); //mensaje que se muestra con el valor
            System.out.print("%");
            porcentajeDB = numAlumDB /totalAlum *100; //operación a realizar
            porcentajeDB = Math.round(porcentajeDB * 10) / 10f; //operación a realizar
            System.out.printf("\n- Módulo de Bases de datos: %.1f", porcentajeDB); //mensaje a mostrar con el valor
            System.out.print("%");
            }else{
            System.out.println(" es 0% en Programación, en Entornos de Desarrollo y Bases de Datos.");//si no se cumple la condición se muestra el siguiente mensaje
            }
        
    }
}
