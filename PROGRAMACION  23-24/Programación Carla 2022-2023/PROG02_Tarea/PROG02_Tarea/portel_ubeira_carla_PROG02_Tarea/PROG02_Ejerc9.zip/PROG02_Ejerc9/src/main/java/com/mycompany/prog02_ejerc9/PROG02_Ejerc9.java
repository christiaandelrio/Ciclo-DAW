/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc9;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc9 {

    public static void main(String[] args) {
        int ano = 1985;
        System.out.print("El año " +ano);
        if((ano % 4 == 0) && (ano % 100 != 0) || (ano % 100 == 0) && (ano % 400 == 0)) {
            //Se establece la condición de si es divisible entre cuatro pero no entre 100 o si es divisibke entre 100 y entre 400, es bisiesto
            //sino se cumple la condición, muestra el mensaje de que no lo es
        System.out.print(" es bisiesto.");
        } else {
        System.out.print(" no es bisiesto.");    
        }
    }
}
