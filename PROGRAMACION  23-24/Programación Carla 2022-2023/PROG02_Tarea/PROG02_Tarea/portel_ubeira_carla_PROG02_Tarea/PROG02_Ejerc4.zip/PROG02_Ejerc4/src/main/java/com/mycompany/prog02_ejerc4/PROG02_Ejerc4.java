/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc4;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc4 {

    public static void main(String[] args) {
    byte edad; //declaramos la variable de tipo byte ya que la edad alcanza valores de entre 0 a 110 años
    //entrando dentro del rango de byte que es -128 a 127
    edad = 18; //inicializamos dicha variable con el valor "18"
    System.out.println("Si tienes " +edad +" años " +(edad >= 18?"eres mayor de edad.":"eres menor de edad.")); //establecemos que si la variable es mayor o igual que 18 es true (mayor de edad)
    //por lo que si no es mayor o igual que 18 es false (no es mayor de edad)
    }
}
