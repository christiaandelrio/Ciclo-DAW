/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc5;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc5 {

    public static void main(String[] args) {
        double seg; //declaramos la variable double en coma flotante de doble precisión
        seg = 86460; //inicializamos la variable con un valor
        System.out.print(seg +" segundos son:\n" +"- " +(seg / 60) +" minutos\n" +"- " +(seg / 3600) +" horas\n" +"- " +(seg/86400) +" días.");
    } //cerramos llaves de main
} //cerramos llaves de clase
