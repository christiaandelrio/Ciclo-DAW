/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prog02_ejerc7;

/**
 *
 * @author yo
 */
public class PROG02_Ejerc7 {
    
    public static void main(String[] args) {
    double C1 = 1; //creamos la variables C! y C2 de tipo double en coma flotante de doble precisión 
    double C2 = 3; //le asignamos un valor a C1 y C2
    double x; //creamos la variable x sin asignarle ningún valor ya que es la incógnita
        System.out.println("La ecuación de primer grado C1x+C2=0 ");
        if(C1 != 0){ //declaramos if ordenando que se ejecute el bloque de código 
            x = -C2 / C1; //si la condición se cumple se realiza la siguiente operación
            System.out.printf("tiene solución\nx=%.4f" ,x); //para que el resultado se muestre con 4 decimales usamos printf
        }else{ //sino se cumple la condición no se realiza la operación
            System.out.print(" no tiene solución."); //se muestra el mensaje de que no tiene solución
        }
       
    }
}
