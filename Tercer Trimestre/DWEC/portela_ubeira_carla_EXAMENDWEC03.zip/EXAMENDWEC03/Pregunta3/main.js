//Definimos la función que se iniciará cada vez que se cargue la ventana
const iniciar = () =>{
    //input
    const cajaFrase=document.getElementById("frase");
    cajaFrase.value="";
    //error
    const error=document.getElementById("errorFrase");
    //divs
    const rombo=document.getElementById("rombo");
    rombo.innerHTML="";
    const temperatura=document.getElementById("temperatura");
    temperatura.innerHTML="";
    //botones
    const botonEnviar=document.getElementById("enviar");
    const botonBorrar=document.getElementById("borrar");
    const botonTiempo=document.getElementById("tiempo");
    //ponemos el foco en el input
    cajaFrase.focus(); 
    
    //Funciones
    const comprobarFrase = () => { //Validación de la frase
        cajaFrase.style.color="";
        const frase=cajaFrase.value;
        let patronNombre=/[A-Za-zÑñÁáÉéÍíÓóÚú]{1,50}/;
            if(!frase.match(patronNombre)){
                error.style.display="inline";
            }
    }
    
    const mostrarRombo=()=>{ //Mostrar rombo
        cajaFrase.style.backgroundColor="grey";
        let fraseRaw=cajaFrase.value;
        let fraseT=fraseRaw.trim();//Quitamos los espacios al principio y al final de la frase
        let fraseR=fraseT.replace(/\s+/g,'');//Quitamos los espacios o los dobles espacios de la frase
        const letras=fraseR.split('');//Dividimos la frase en letras que guardamos en un array
        const medio= Math.floor(11 / 2 + 1);
        rombo.innerText = '';
        let pos=0;//posición de las letras en el array de letras
        //Dibujamos la parte superior                
        for (let fila = 0; fila < medio -1; fila++) {
            for (let columna = 1; columna <= 20; columna++) {
                if ((columna == medio - fila) || (columna == medio + fila )) {
                    if(pos<letras.length){
                        rombo.innerText += letras[pos];
                        pos++; 
                    }
                } else {
                    rombo.innerText += ('\u00a0');
                }
            }
            rombo.innerText += '\n';
        }
        // Dibujamos la parte inferior rombo:
        for (let fila = medio - 1 ; fila > 0; fila--) {
        for (let columna = 1; columna <= 20; columna++) {
            if ( (columna == medio - fila) || (columna == medio + fila ) ) {
                if(pos<letras.length){
                    rombo.innerText += letras[pos];
                    pos++; 
                }
            } else {
                rombo.innerText +=  '\u00a0';
            }
        }
        rombo.innerText += '\n';
        }
    
    }
    const actualizarTiempo = () =>{//Actualizar ell tiempo
        $('#temperatura').html('<div class="loading"><img src="./loader.gif" alt="loading" /><p>Cargando...</p></div>');
        $('#temperatura').delay(3000);
        $('#temperatura').fadeOut("slow");
        let key="51e83375a3a499800e5613d9eda1e766";//Metemos la clave de la api Openweather
        let url=`https://api.openweathermap.org/data/2.5/weather?&lat=42.264799151433&lon=-8.765128490705925&units=metric&lang=es&appid=${key}`;
        const cargarDatos=()=>{
            $.getJSON(url,function(datos){
                let tiempo=`${datos.weather[0].description}`.toUpperCase();
                temperatura.style.backgroundColor="grey";
                $('#temperatura').fadeIn(1000).html(`<p style='backgroundColor:grey;'>La temperatura en el exterior es de ${tiempo}</p>`);
                
            });
        }
        setTimeout(cargarDatos,3500);//Con esta función atrasamos la ejecución de la función que cargará los datos del JSON
    }
    //Si se clica en el botón de borrar, se borrarán todos los campos del formulario
    const borrar = () => {
        cajaFrase.style.color="";
        cajaFrase.value="";
        error.style.display="none";
        rombo.innerText="";
        temperatura.innerText="";
        cajaFrase.focus();
    } 

    //listeners
    cajaFrase.addEventListener('blur',comprobarFrase, false);//El evento se produce cuando se cambia de campo
    botonBorrar.addEventListener('click', borrar, false); //El evento se produce cuando se clica en el botón
    botonEnviar.addEventListener('click',mostrarRombo, false);//El evento se produce cuando se clica en el botón
    botonTiempo.addEventListener('click', actualizarTiempo);
}


//Cada vez que se cargué la ventana, se llamará a la función iniciar
window.addEventListener('load', iniciar, false);