//Función que se iniciará cada vez que se cargue la ventana
const iniciar = () =>{
    
    //Inputs
    const cajaFrase=document.getElementById("frase");
    const cajaComplejidad=document.getElementById("complejidad");
    let frase="";
    let complejidad="";
    
    //Errores
    const errorFrase=document.getElementById("errorFrase");
    const errorComplejidad=document.getElementById("errorComplejidad");

    //Botones
    const botonJugar=document.getElementById("jugar");
    const botonLimpiar=document.getElementById("limpiar");

    //Contadores e intentos
    const divContadores=document.getElementById("contadores");
    const cajaContador=document.getElementById("contador");
    const cajaIntentos=document.getElementById("intentos");
    let contador="";
    let intentos=0;

    //Contenedor donde vamos a colocar el tablero
    const contenedorTablero=document.getElementById("zonadibujo");

    //Funciones
    const comprobarFrase = () => { //Para validar la frase
        let patronNombre=/^[A-Za-z\sÑñÁáÉéÍíÓóÚú]{1,50}$/i;
        frase=cajaFrase.value;
            if(!frase.match(patronNombre)){
                cajaFrase.style.color="red";
                errorFrase.style.display="inline";
                cajaFrase.focus();
            } else {
                cajaFrase.style.color="";
                errorFrase.style.display="none";
            }
            
    }
    const comprobarComplejidad = () => { //Para validar la complejidad
        complejidad=Number(cajaComplejidad.value);
        if(complejidad < 10 || complejidad > 50){
            cajaComplejidad.style.color="red";
            errorComplejidad.style.display="inline";
            cajaComplejidad.focus();
        } else {
            cajaComplejidad.style.color="";
            errorComplejidad.style.display="none";
            botonJugar.style.display="inline";
        }
        
    }
        
    const borrar = () => { //Para borrar todos los campos
        contador=0;
        intentos=0;
        cajaFrase.value="";
        cajaComplejidad.value="";
        cajaContador.value="";
        cajaIntentos.value="";
        divContadores.style.display="none";
        botonLimpiar.style.display="none";
        botonJugar.style.display="none";
        contenedorTablero.innerHTML="";
        cajaFrase.focus();
        
    } 

    const jugar = () => {//Para iniciar el juego
        contenedorTablero.innerHTML="";
        //1 - CREAMOS EL TABLERO CON LAS CELDAS
        
        //Creamos los elementos de la tabla
        let tablero=document.createElement("table");
        let tableroBody=document.createElement("tbody");

        //Creamos las celdas  y filas mediante un bucle for
        for(let i=0; i<complejidad; i++){
            //Creamos las filas
            let fila=document.createElement("tr");
            for(let j=0; j<complejidad; j++){
                //Por cada fila creamos una celda  y establecemos el atributo style a background-color white y el alto y el ancho en 10 px
                let celda=document.createElement("td");
                celda.style.backgroundColor="grey"; //Ponemos en el mismo color de fondo y de color de la letra de las celdas para ocultar su contenido
                celda.style.color="grey";
                celda.style.width="15px";
                celda.style.height="15px";
                celda.style.textAlign="centre";
                //Una vez creadas las celdas las añadimos a la fila
                fila.appendChild(celda);
            }
        //Añadimos las final al body
        tableroBody.appendChild(fila);
        }
        //Añadimos el body a la tabla y lo metemos en el correspondiente div
        tablero.appendChild(tableroBody);
        tablero.setAttribute("border", "2");
        tablero.setAttribute("id", "tabla");
        contenedorTablero.appendChild(tablero);

        //2 - AÑADIMOS LAS LETRAS DE LA FRASE AL TABLERO

        //Creamor un array con las celdas del tablero
        const celdas=contenedorTablero.getElementsByTagName("td");

        //Creamos un array con las letras de la frase
        let fraseT=frase.trim(); //Quitamos los espacios al inicio y al final
        let fraseR=fraseT.replace(/\s+/g,'');//Mediante esta regEx quitamos todo los espacios (incluso lo espacios consecutivos) de todo el string(g), sino g ssólo eliminaríamos el primer espacio
        const arrayLetras=fraseR.split('');//Total de todas las letras que tenemos que encontrar

        //Establecemos el contador de letras de la frase que nos quedan por averiguar
        contador=arrayLetras.length;
        cajaContador.value=contador;//Ponbemos el contador con el valor del total de letras a descubrir
        intentos=0;
        cajaIntentos.value=intentos;//Ponbemos el contador con el valor del total de letras a descubrir
        divContadores.style.display="inline";

        //Mostramos el botón de limpiar
        botonLimpiar.style.display="inline";

        //Pintamos en celdas aleatorias las letras de la frase
        for(let i=0; i<arrayLetras.length; i ++){ 
            let letraCelda=arrayLetras[i];//Cogemos una letra del array de letras y calculamos una posición en el array de celdas al azar
            let posicionCeldaAzar = Math.floor(Math.random() * celdas.length -1);//-1 ya que la primera posición del array de celdas es 0
            celdas[posicionCeldaAzar].innerText=`${letraCelda}`;//ponemos la letra del arrayLetras en una celda aleatoria
        }
        
        //3 - ESTABLECEMOS LO QUE PASARÁ CUANDO SE PINCHE UNA CELDA
        const descubrirCelda  = (evento) =>{
            const elemento=evento.target;//la propiedad target del objeto Event es el elemento en el que se originó el evento(osea, la celda)
            elemento.removeEventListener("click",descubrirCelda,true);//Una vez que se pincha en la celda no se puede volver a seleccionar
            let colorAleatorio = "#" + Math.floor(Math.random() * 16777215).toString(16);
            elemento.style.backgroundColor="white";//Descubrimos la celda asginando un fondo blanco y cambiando el color del texto
            elemento.style.color=colorAleatorio;//Se asigna un color aleatorio al texto 
            let letra=elemento.innerText;
            if(letra != ""){
                contador--;
                cajaContador.value=contador;
            } else {
                intentos++;
                cajaIntentos.value=intentos;
            }
            if(contador==0){//Si se han encontrado todas las letras
                borrar();//Terminamos el juego
                contenedorTablero.innerHTML="<h2>¡ENHORABUENA!<br>Has encontrado todas las letras</h2>";
            }   
        }
            
        //Para cada celda del tablero añadimos un addEventListener que llamará a la función descubrir
        for(let j=0; j<celdas.length;j++){
            celdas[j].addEventListener("click",descubrirCelda, true);
        }
    }

    //Al cargase la página se pone el foco en el primer input
    cajaFrase.focus(); 

    //Añadimos los eventos a los inputs y a los botones
    cajaFrase.addEventListener('blur',comprobarFrase, false);//El evento se produce cuando se cambia de campo
    cajaComplejidad.addEventListener('blur',comprobarComplejidad, false);
    botonLimpiar.addEventListener('click', borrar, false); //El evento se produce cuando se clica en el botón
    botonJugar.addEventListener('click',jugar, false);//El evento se produce cuando se clica en el botón
        
}

//Cada vez que se cargué la ventana, se llamará a la función iniciar
window.addEventListener('load', iniciar, false);
