<?php


 function autoload_83fb7ccc10e7421abef1a18cf7e945f9($class)
{
    $classes = array(
        'Clases\Gate' => __DIR__ .'/Gate.php',
        'Clases\ExchangeRatesDS' => __DIR__ .'/ExchangeRatesDS.php',
        'Clases\ExchangeRates' => __DIR__ .'/ExchangeRates.php',
        'Clases\ISOCodes' => __DIR__ .'/ISOCodes.php',
        'Clases\ExchangeRatesByRange' => __DIR__ .'/ExchangeRatesByRange.php',
        'Clases\ISOCodesDetailed' => __DIR__ .'/ISOCodesDetailed.php',
        'Clases\ISOCodesDetailedResponse' => __DIR__ .'/ISOCodesDetailedResponse.php',
        'Clases\ISOCodesDetailedResult' => __DIR__ .'/ISOCodesDetailedResult.php',
        'Clases\ISOCodesResponse' => __DIR__ .'/ISOCodesResponse.php',
        'Clases\ArrayOfString' => __DIR__ .'/ArrayOfString.php',
        'Clases\ExchangeRatesLatestByISO' => __DIR__ .'/ExchangeRatesLatestByISO.php',
        'Clases\ExchangeRatesLatestByISOResponse' => __DIR__ .'/ExchangeRatesLatestByISOResponse.php',
        'Clases\ArrayOfExchangeRate' => __DIR__ .'/ArrayOfExchangeRate.php',
        'Clases\ExchangeRate' => __DIR__ .'/ExchangeRate.php',
        'Clases\ExchangeRatesByDateByISO' => __DIR__ .'/ExchangeRatesByDateByISO.php',
        'Clases\ExchangeRatesByDateByISOResponse' => __DIR__ .'/ExchangeRatesByDateByISOResponse.php',
        'Clases\ExchangeRatesByDate' => __DIR__ .'/ExchangeRatesByDate.php',
        'Clases\ExchangeRatesByDateResponse' => __DIR__ .'/ExchangeRatesByDateResponse.php',
        'Clases\ExchangeRatesLatest' => __DIR__ .'/ExchangeRatesLatest.php',
        'Clases\ExchangeRatesLatestResponse' => __DIR__ .'/ExchangeRatesLatestResponse.php',
        'Clases\ExchangeRatesByDateRangeByISO' => __DIR__ .'/ExchangeRatesByDateRangeByISO.php',
        'Clases\ExchangeRatesByDateRangeByISOResponse' => __DIR__ .'/ExchangeRatesByDateRangeByISOResponse.php',
        'Clases\ExchangeRatesByDateRangeByISOResult' => __DIR__ .'/ExchangeRatesByDateRangeByISOResult.php'
    );
    if (!empty($classes[$class])) {
        include $classes[$class];
    };
}

spl_autoload_register('autoload_83fb7ccc10e7421abef1a18cf7e945f9');

// Do nothing. The rest is just leftovers from the code generation.
{
}
