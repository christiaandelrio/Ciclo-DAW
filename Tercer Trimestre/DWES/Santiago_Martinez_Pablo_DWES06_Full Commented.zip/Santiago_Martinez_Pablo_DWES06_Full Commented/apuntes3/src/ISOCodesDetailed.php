<?php

namespace Clases;

class ISOCodesDetailed
{

    
    public function __construct()
    {
    
    }

}
