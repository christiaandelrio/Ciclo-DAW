<?php

namespace Clases;

class ExchangeRatesLatest
{

    
    public function __construct()
    {
    
    }

}
