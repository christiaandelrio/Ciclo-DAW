<?php

namespace Clases;

class ISOCodes
{

    
    public function __construct()
    {
    
    }

}
