Esta carpeta se corresponde con los apartados de los apuntes:

2.1.2.- Utilización de un servicio web (III)
 -> uso de Wsdl2PhpGenerator


2.1.3.- Utilización de un servicio web (IV)
