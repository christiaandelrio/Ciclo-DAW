<?php
require '../vendor/autoload.php';
//Esto es una prueba que hizo David.

//Se crea esta clase
use Clases\Pub_gestdocente;
//Si vemos la clase pubdocente nos aparece en el listado y ahora creamos un objeto titulos uni.
use Clases\wstitulosuni;



//Se coge la puerta de entrada que es esta.
//La puerta es la que se encarga de invocar la funcion del objeto que buscamos.
$puerta = new Pub_gestdocente();

//Se genera el servicio y se le dice al servicio que queremos las busquedas con los parametros o valores español y 2023 
//(eso lo buscamos en el constructor , y ahi vemos lo que recibe y son strings.)
$servicio = new wstitulosuni('es', '2023');
//Invocamos el servicio web titulos uni. y meterlo en el espacio de nombres.
$respuesta = $puerta->wstitulosuni($servicio);
//El parametro wstitulosuni nos devuelve un wstitulos response.
//vamos a wstitulosresponse.php y ahi vemos los metodos donde podemos sacar la información
//El metodo wstitulosresponse nos devuelve un array.
//asi que guardamos ese array en una variable lista titulos.
$listaTitulos = $respuesta->getWstitulosuniResult();

//Y le decimos que imprima la lista de titulos con echo.

echo "Número de títulos: " . $listaTitulos->count() . "<br>" . PHP_EOL;


for ($i = 0; $i <  $listaTitulos->count(); $i++ ) {
    //Guardamos el titulo actual
    $titulo = $listaTitulos->current();
    //Hacemos un echo para sacar el numero de titulo con un br para el DOM y un PHP_EOL para que salga por consola
    echo "nº titulo: " . ($i +1) . "<br>" . PHP_EOL;
    echo "Código título: ". $titulo->getCodigo()  . "<br>" . PHP_EOL;
    echo "Nombre título: ". $titulo->getNombre()  . "<br>" . PHP_EOL;
    //Con esto pasa al siguiente titulo y continua el bucle.
    $listaTitulos->next();
}
// var_dump($listaTitulos );

