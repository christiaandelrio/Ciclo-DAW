<?php
//0)Previamente ejecutamos en la terminal: php -i | findstr /I "soap" (Esto devuelve la info de PHP).
//Luego php - ini.
//No nos devuelve nada sobre SOAP.
//Vamos a la carpeta de PHP y abrimos PHP.ini y buscamos SOAP
//;extension=soap aparece comentada , se descomenta. Para que descargue la extension SOAP.
//Deshabilitamos la caché y se hace: Descomentando la linea: "soap.wsdl_cache_enabled=0".
//Para que aplique se debe reiniciar el apache.

//podemos comprobarlo haciendo un php -i | findstr /I "soap" de nuevo.

//Una vez que nos aseguramos que funciona pasariamos a:

/* 1)Hacemos un composer update sobre esta carpeta (apuntes) , boton derecho , abrir terminal 
y "composer update".
Esto mete en la carpetita composer dentro de vendor todo lo que necesitamos y nos 
genera todas las clases en la carpeta vendor. Que son las que necesitamos con el archivo wsdl2phpgenerator */

//En el primer apartado (tenemos que tener en htdocs el director dwes_tema_06) , abrimos un localhost y 
//hacemos doble click en generar.php y no pasaría nada. Nos daría un error indicanonos el fichero y la linea.
// Lo comentamos y entonces nos generaría un montón de clases en la carpeta "public/sr".

//Ahora el profesor comprueba mediante el nombre del inputfile de wsdl y lo utiliza como un filtro en wireshark para ver el tráfico.
//Lo hace mediante ip add==cvnet.cpd.ua.es como no funciona hace en cmd un ping a cvnet.cpd.ua.es y coge la ip buscando el mismo .


//Fichero para generar las clases
require '../vendor/autoload.php';


//Importante , este paquete es el que nos genera en public/src nos generó todo el codigo que necesitamos para interaccionar.
//Además hay tipos de datos que nos pueden transformar xml a un array de strings u otros tipos.
use Wsdl2PhpGenerator\Generator;
use Wsdl2PhpGenerator\Config;




// Desactivar comprobación de certificado raíz
//Modificacion hecha por DAVID donde se introduce un fichero de certificados.Para pasar un contexto SSL.
//Si usamos el cliente SOAP debemos configurar el protocolo https para que utilice el certificado de las lineas bajo este comentario.
//Tambien podemos deshabilitar que compruebe el servidor por si nos conectamos y no va , no va.
$context = stream_context_create([
    'ssl' => [
        // set some SSL/TLS specific options
        // 'verify_peer' => false,
        //'verify_peer_name' => false,
        //'allow_self_signed' => true,
        'cafile' => 'cacert-2023-01-10.pem'
    ]
]);

//EXPLICACION:

//Si nos intentamos conectar directamente nos falla la conexión si utilizamos http y a veces en otros solo
//podemos utilizar https porque tenemos que pasarle un fichero de certificados que está justo arriba.



// Generar
//2) Cuando esto se ejecuta , se contacta con el servicio SOAP y construye todas las clases en la carpeta SRC que ahora está vacia.
$generator = new Generator();
$generator->generate(
    new Config([
        'inputFile' => 'https://cvnet.cpd.ua.es/servicioweb/publicos/pub_gestdocente.asmx?WSDL', //wsdl
        'outputDir' => '../src',  //directorio donde vamos a generar las clases
        'namespaceName' => 'Clases', //namespace que vamos a usar con ellas (indicar en composer)
        'soapClientOptions' => array(
        	// 'authentication' => SOAP_AUTHENTICATION_BASIC,
        	// 'login' => 'username',
        	// 'password' => 'secret',
        	// 'connection_timeout' => 60,
            'stream_context' => $context
            )
    ])
);