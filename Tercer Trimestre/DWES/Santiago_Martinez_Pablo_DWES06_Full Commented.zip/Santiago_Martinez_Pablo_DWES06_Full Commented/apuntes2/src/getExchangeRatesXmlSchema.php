<?php

namespace Clases;

class getExchangeRatesXmlSchema
{

    
    public function __construct()
    {
    
    }

}
