<?php

namespace Clases;

class getListOfCurrencies
{

    
    public function __construct()
    {
    
    }

}
