Esta carpeta es otro ejemplo adicional para
 el apartado de los apuntes:

2.1.2.- Utilización de un servicio web (III)
 -> uso de Wsdl2PhpGenerator