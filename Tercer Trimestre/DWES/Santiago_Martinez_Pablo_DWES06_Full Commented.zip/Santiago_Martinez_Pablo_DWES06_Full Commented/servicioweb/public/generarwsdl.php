<?php
//0)Primero se realiza un composer update en el directorio Servicioweb/public.
//En segundo lugar realizaremos el mismo procedimiento que antes de generar wsdl que cree la clase
//Este archivo es una plantilla.
//Luego se usará este archivo de nuevo copiandolo y modificando unas pocas cosas.

//Importante este require, si no no funcionaría.
   require '../vendor/autoload.php';

   use PHP2WSDL\PHPClass2WSDL;

   $class = "Clases\\Operaciones";
   $uri = 'http://127.0.0.1/dwes_tema_06/servicioweb/servidorSoap/servidorW.php';
   $wsdlGenerator = new PHPClass2WSDL($class, $uri);
   $wsdlGenerator->generateWSDL(true);
   $fichero = $wsdlGenerator->save('../servidorSoap/servicio.wsdl');