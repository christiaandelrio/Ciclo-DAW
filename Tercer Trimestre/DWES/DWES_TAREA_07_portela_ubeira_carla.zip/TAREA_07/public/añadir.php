<?php
//PÁGINA PARA AÑADIR UN NUEVO PRODUCTO
session_start();
 
require '../src/Validar.php';//Incluye la página con la funcionalidad de validación
require  '../src/Producto.php';

//Preparamos Jaxon
use function Jaxon\jaxon;
// Procesar la solicitud
if($jaxon->canProcessRequest())  $jaxon->processRequest(); //Método encargado de procesar las llamadas que reciba la página

//Cargamos todas las familias que se mostrarán en el select del formulario
$producto=new Producto();
$familias=$producto->listadoFamilias();
$producto=null;

?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Formulario JAXON</title>
    <script type="text/javascript" src="../js/validar.js"></script>

</head>

<body style="background:#00bfa5;">

    <div class="container mt-5">
        <div class="d-flex justify-content-center h-100">
            <div class="card" style='width:24rem;'>
                <div class="card-header">
                    <h3><i class="fa fa-cog mr-1"></i>Nuevo producto</h3>
                </div>
                
                <div class="card-body">
                    <!--Para ejecutar el código de alta del producto, se crea la función Javascript en archivo externo (validar.js) y se asigna al evento "on submit" del formulario-->
                    <form name='miForm' id="miForm" method='post' action="listado.php" onsubmit="return altaProd();">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-shopping-basket"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="nombre" id='nombre' name='nombre'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-shopping-bag"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="nombre corto" id='nombre_corto' name='nombre_corto'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="far fa-bookmark"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="descripción" id='descripcion' name='descripcion'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="far fa-money-bill-alt"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="precio" id='pvp' name='pvp'>
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-map-signs"></i></span>
                                <select class="form-select form-control" id="familia" name="familia">
                                    <option value="Elige tu tienda más cercana" selected>Escoge una familia</option>
                                    <?php 
                                    for($i=0;$i<count($familias);$i++){
                                        echo "<option value='{$familias[$i]}'>{$familias[$i]}</option>";
                                    }
                                    $familias=null;
                                    
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Añadir" class="btn float-right btn-info" name='enviar' id="enviar">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
<?php
$jaxon = jaxon();//Instanciamos el objeto jaxon
echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n"; //Inyectamos el código javascript
echo "<!-- HTTP comment  -->\n"
?>

</html>