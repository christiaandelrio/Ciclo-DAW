<?php
//PÁGINA PARA DAR DE ALTA NUEVOS PRODUCTOS SIN STOCK Y LISTARLOS
session_start();
 
if (!isset($_SESSION['usu'])) {//Si no se ha iniciado la sesión de usuario(y por lo tanto, no se ha producido la validación del usurio), se redirige a login.php
    header('Location:login.php');
    die();
}
//Variables de sesión con usuario y tienda
$usu=$_SESSION['usu'];
$ciudad=$_SESSION['ciudad'];

spl_autoload_register(function ($clase) {
    include "../src/" . $clase . ".php";
});

require '../src/Validar.php';//Incluye la página con la funcionalidad de validación
require  '../src/Producto.php';
require  '../src/Stock.php';

function pintarEstrellasPagina($p)  {

    $votos     = new Voto();//Se instancia un objeto de la clase Voto para poder utilizar su funcionalidad
    $c         = $votos->getMedia($p);//Obtenemos la media mediante el método de clase getMedia
    $en        = intval($c);//Pasamos a un entero el resultado de la media
    $dec       = $c - $en;//Le restamos al entero de la media, la media obtenida para obtener la parte decimal
    $estrellas = "{$votos->getTotalVotos($p)} Valoraciones. ";//Obtenemos el total de los votos

    if ($en > 0) {
        for ($i = 1; $i <= $en; $i++) {//Si el entero de la media es mayor a 0, por cada punto pintamos una estrella entera
            $estrellas .= "<i class='fas fa-star'></i>";//Concatenamos estrellas
        }

        if ($dec >= 0.5)//Por cada parte decimal mayor o igual a 0,5, pintaremos media estrella
            $estrellas .= "<i class='fas fa-star-half-alt'></i>";
    } else {
        $estrellas = "Sin valorar";//Si la media es menor que 0, no se pintaran estrellas
    }

    $votos = null;//Inicializamos la variable votos al terminar la función
    return $estrellas;//Devolvemos las estrellas
}

//preparamos el Jaxon
use function Jaxon\jaxon;
// Procesar la solicitud
if($jaxon->canProcessRequest())  $jaxon->processRequest(); //Método encargado de procesar las llamadas que reciba la página

//cargamos todas las tiendas
$producto=new Producto();
$familias=$producto->listadoFamilias();
$producto=null;

//1 - Obtener la lista de productos propuestos
//cargamos todos los productos(id)
$producto=new Producto();
$productosTotal=$producto->listadoProductosId();
$producto=null;
//Verificamos si hay stock para cada producto
$stock=new Stock();
for($i=0;$i<count($productosTotal);$i++){
    if(!$stock->existeStock($productosTotal[$i])){
        $productosSinStock [] = $productosTotal[$i];
    }
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Formulario JAXON</title>
    <script type="text/javascript" src="../js/validar.js"></script>

</head>

<body style="background:#00bfa5;">
<div class="float float-right d-inline-flex mt-2">
        <i class="fas fa-user mr-3 fa-2x"></i>
        <input type="text" size='10px' value="<?php echo $usu; ?>" class="form-control
    mr-2 bg-transparent text-white font-weight-bold" disabled>
        <i class="fas fa-map-pin mr-3 fa-2x"></i>
    <input type="text" size='10px' value="<?php echo $ciudad;?>" class="form-control
    mr-2 bg-transparent text-white font-weight-bold" disabled>
    <i class="fas fas fa-heart mr-3 fa-2x"></i>
        <a href="votos.php" class="btn btn-success mr-2">Votos</a>
        <a href="añadir.php" class="btn btn-secondary mr-2">Añadir</a>
        <a href="proponer.php" class="btn btn-secondary mr-2">Proponer</a>
        <a href="cerrar.php" class="btn btn-warning mr-2">Salir</a>
    </div>
    <br>
    <div class="container mt-5">
        <div class="d-flex justify-content-center h-100">
            <div class="card" style='width:24rem;'>
                <div class="card-header">
                    <h3><i class="fa fa-cog mr-1"></i>Proponer producto</h3>
                </div>
                
                <div class="card-body">
                    <!--Para ejecutar el código de validación, se crea la función Javascript en archivo externo (validar.js) y se asigna al evento "on submit" del formulario-->
                    <form name='miForm' id="miForm" method='post' action="listado.php" onsubmit="return altaProd();">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-shopping-basket"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="nombre" id='nombre' name='nombre'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-shopping-bag"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="nombre corto" id='nombre_corto' name='nombre_corto'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="far fa-bookmark"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="descripción" id='descripcion' name='descripcion'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="far fa-money-bill-alt"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="precio" id='pvp' name='pvp'>
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-map-signs"></i></span>
                                <select class="form-select form-control" id="familia" name="familia">
                                    <option value="Elige tu tienda más cercana" selected>Escoge una familia</option>
                                    <?php 
                                    for($i=0;$i<count($familias);$i++){
                                        echo "<option value='{$familias[$i]}'>{$familias[$i]}</option>";
                                    }
                                    $familias=null;
                                    
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Añadir" class="btn float-right btn-info" name='enviar' id="enviar">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <h4 class="container text-center mt-4 font-weight-bold">Productos propuestos que no existen en tienda</h4>
    <div class="container mt-3">
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th scope="col" class='text-center'>Código</th>
                    <th scope="col" class='text-center'>Nombre</th>
                    <th scope="col" class='text-center'>Valoración</th>
                    <th scope="col" colspan="2" class='text-center'>Valorar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //Por cada producto sin stock, imprimimos en una tabla su nombre y el resto de caracterísitcas asociadas
                for ($j=0; $j<count($productosSinStock);$j++) {
                    $id=$productosSinStock[$j];
                    $producto= new producto();
                    $producto->setId($id);
                    $nombre = $producto->getNombreById();
                    echo "<tr class='text-center'>\n";
                    echo "<th scope='row'>{$id}</th>\n";
                    echo "<td>{$nombre}</td>\n";
                    echo "<td><div id='votos_{$id}' class='float-left'>";
                    echo pintarEstrellasPagina($id);
                    echo "</div> </td>\n";
                    echo "<td><select name='puntos' class='form-control' id='spuntos_{$id}'>";
                    for ($i = 1; $i <= 5; $i++) {
                        echo "<option>$i</option>\n";
                    }
                    echo "</select>\n";
                    echo "</td><td>";
                    echo "<button class='btn btn-info' onclick=\"envVoto('{$usu}','{$id}')\">Votar</button>";
                    echo "</td>\n";
                    echo "</tr>\n";
                    $producto=null;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
<?php
$jaxon = jaxon();//Instanciamos el objeto jaxon
echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n"; //Inyectamos el código javascript
echo "<!-- HTTP comment  -->\n"
?>
</html>