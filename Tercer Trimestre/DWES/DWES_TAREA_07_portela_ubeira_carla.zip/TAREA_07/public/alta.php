<?php
//PÁGINA PARA DAR DE ALTA UN NUEVO USUARIO

session_start();

require '../src/Validar.php';//Incluye la página con la funcionalidad de validación

//Preparamos Jaxon
use function Jaxon\jaxon;
// Procesar la solicitud
if($jaxon->canProcessRequest())  $jaxon->processRequest(); //Método encargado de procesar las llamadas que reciba la página
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Formulario JAXON</title>
    <script type="text/javascript" src="../js/validar.js"></script>

</head>

<body style="background:#00bfa5;">

    <div class="container mt-5">
        <div class="d-flex justify-content-center h-100">
            <div class="card" style='width:24rem;'>
                <div class="card-header">
                    <h3><i class="fa fa-cog mr-1"></i>Nueva alta</h3>
                </div>
                <div class="card-body">
                    <!--Para ejecutar el código de validación, se crea la función Javascript en archivo externo (validar.js) y se asigna al evento "on submit" del formulario-->
                    <form name='alta' id="alta" method='post' action="listado.php" onsubmit="return envAlta();">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="usuario" id='usu' name='usu'>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" class="form-control" placeholder="contraseña" id='pass' name='pass'>
                        </div>
                        
                        <div class="form-group">
                            <input type="submit" value="Registrar" class="btn float-right btn-info" name='registrar' id="registrar">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
<?php
$jaxon = jaxon();//Instanciamos el objeto jaxon
echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n"; //Inyectamos el código javascript
echo "<!-- HTTP comment  -->\n"
?>

</html>