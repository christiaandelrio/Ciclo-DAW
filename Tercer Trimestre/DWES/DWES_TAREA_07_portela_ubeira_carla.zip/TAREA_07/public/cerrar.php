<?php
//PÁGINA PARA CERRAR SESIÓN
session_start();

//Borra las variables de sesión y redirige a login.php
if (isset($_SESSION['usu'])){
    unset($_SESSION['usu']);
    unset($_SESSION['ciudad']);
} 

header('Location: login.php');
