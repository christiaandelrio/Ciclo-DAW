//En esta archivo se crea la función javascript que se encargará de gestionar el envio de votos mediante la funcion php miVoto y votoValido
function envVoto(usu, pro) {//LLama la función php de votar.php
    id = "spuntos_" + pro;
    var puntos = document.getElementById(id).value;
    
    jaxon_miVoto(usu, pro, puntos);
}

function cambiarVoto(usu, pro) {//LLama la función php de votar.php
    id = "spuntos_" + pro;
    var puntos = document.getElementById(id).value;
    
    jaxon_cambiarVoto(usu, pro, puntos);
}
//Pinta las estrellas con los datos del nuevo voto añadido
function votoValido(datos) {
    jaxon_pintarEstrellas(datos['media'], datos['pro']);
}
//Muestra que el voto se ha actualizado y pinta las estrellas correspondientes
function votoActualizado(datos) {
    alert("Voto actualizado");
    jaxon_pintarEstrellas(datos['media'], datos['pro']);
}
//Muestra que el voto ya existia y por lo tanto no ha sido actualizado
function votoNoActualizado () {
    alert("Ya existe este voto para este producto");
}