// [JAXON-PHP]

//En esta archivo se crean las funciones javascript que se encargarán de gestionar:

//1 - Validación del usuario en login.php
function envForm() {
    let usu = document.getElementById("usu").value;
    let pass = document.getElementById('pass').value;
    let ciudad=document.getElementById("ciudad").value;
    //llamamos por AJAX al php:
    jaxon_validar(usu, pass, ciudad);
    //anulamos la acción por defecto del formulario:
    return false;
}

//2 - Validación del formulario de alta de nuevo usuario en alta.php
function envAlta(){
    let usu = document.getElementById("usu").value;
    let pass = document.getElementById('pass').value;
    // llamamos por AJAX al php:
    jaxon_vUsuario(usu, pass);
    //anulamos la acción por defecto del formulario:
    return false;
}

//3 - Validación de alta de nuevo producto en añadir.php
function altaProd(){
    let nombre = document.getElementById("nombre").value;
    let nombreCorto = document.getElementById("nombre_corto").value;
    let descripcion = document.getElementById("descripcion").value;
    let pvp = document.getElementById("pvp").value;
    let familia = document.getElementById("familia").value;

    jaxon_añadir(nombre,nombreCorto, descripcion, pvp, familia);
    //anulamos la acción por defecto del formulario:
    return false;
}

//Muestra que el usuario es válido en login.php y redirige a listado.php(Página principal)
function validado() {
    window.open("listado.php", "_self");
}
//Muestra que el usuario no es válido en login.php
function noValidado() {
    alert("¡¡Usuario o contraseña no válidos!!!");
}
//Muestra que el usuario ya existe en alta.php y por lo tanto no se puede crear un usuario nuevo con ese nombre
function yaExiste(){
    alert("Ya existe una cuenta para este usuario");
    document.getElementById("usu").value="";
    document.getElementById("pass").value="";
    document.getElementById("usu").focus();
}
//Muestra que el nuevo usuario ha sido creado con éxito  en alta.php y redirige a login.php para que inicie sesión
function alta(){
    alert("La cuenta se ha creado con éxito");
    window.open("login.php", "_self");
}
//Muestra que el nuevo producto ha sido añadido con éxito en añadir.php y redirige a listado.php
function altaP(){
    alert("El producto se ha añadido con éxito");
    window.open("listado.php", "_self");
}