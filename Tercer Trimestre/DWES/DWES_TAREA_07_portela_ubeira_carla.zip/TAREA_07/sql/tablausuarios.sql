-- 1. -- Seleccionamos la base de datos Proyecto
use proyecto;

-- 2. -- Creamos la tabla usuarios
create table usuarios(
    usuario varchar(50) primary key,
    pass varchar(64) not null
);

-- 3. -- Creamos usuarios de prueba
insert INTO usuarios SELECT 'admin' , sha2('secreto',256);
insert INTO usuarios SELECT 'gestor' , sha2('secreto',256);

INSERT INTO usuarios VALUES ('usuario1', sha2('pusuario1', 256) );
INSERT INTO usuarios VALUES ('usuario2', sha2('pusuario2', 256) );
INSERT INTO usuarios VALUES ('usuario3', sha2('pusuario3', 256) );
INSERT INTO usuarios VALUES ('usuario4', sha2('pusuario4', 256) );