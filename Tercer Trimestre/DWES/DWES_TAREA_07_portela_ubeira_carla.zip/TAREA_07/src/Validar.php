<?php
//CLASE JAXON PHP DE VALIDACIONES DE USUARIO Y PRODUCTO

require 'Conexion.php'; //Incluye la página que inicia la conexión con la db
require 'Usuario.php'; //Incluye la página con la clase usuario y su funcionalidad
require '../vendor/autoload.php';

//Preparamos Jaxon
use Jaxon\Jaxon;
use function Jaxon\jaxon;
$jaxon = jaxon(); //Instanciamos un objeto de la clase jaxon mediante su constructor
//Configuramos Jaxon mediante los métodos de la clase Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);//Desactivamos los mensajes de depuración
$jaxon->setOption('core.debug.verbose', false);

//FUNCIONES
function validar($u, $p, $c)  { //Realiza la validación del usuario en login.php
    $resp = jaxon()->newResponse(); //En cada una de las funciones definidas, se instancia un objeto para devolver el resultado del procedimiento
    if (strlen($u) == 0 || strlen($p) == 0) {//Si el usuario o la contraseña tienen un tamaño de 0, llama a la funcion de Javascript para lanzar el mensaje correspondiente
        $resp->call('noValidado');//LLama al método javascript del archivo validar.js
    } else {
        $usuario = new Usuario();//Sino crea un nuevo objeto de la clase Usuario 
            
        if (!$usuario->isValido($u, $p)) {//Mediante el método de clase isValido, pasamos como parámetros el usuario y la contraseña, y si el resultado es false,
            $resp->call('noValidado');//llamamaos a la función de Javascript para que alerte mediante un mensaje y redirija al usuario a login.php
        } else {
            $_SESSION['usu']=$u;//Guardamos el usuario en una variable de sesión
            $_SESSION['ciudad']=$c;//Guardamos la ciudad seleccionada en una variable de sesión
            $resp->call('validado');//Llamamos a la función de Javascript para que redirija al usuario a la página listado.php
        }
        $usuario = null;//Tras lo cual, vaciamos la variable usuario establecéndola en null
    }
    return $resp;//La función devuelve la variable respuesta, que es un booleano(true o false)
}

function vUsuario($u,$p){ //Valida el usuario y añade el usuario nuevo a la base de datos en alta.php
    $resp = jaxon()->newResponse(); //En cada una de las funciones definidas, se instancia un objeto para devolver el resultado del procedimiento
    if (strlen($u) == 0 || strlen($p) == 0) {//Si el usuario o la contraseña tienen un tamaño de 0, llama a la funcion de Javascript para lanzar el mensaje correspondiente
        $resp->call('noValidado');//LLama al método javascript del archivo validar.js
    } else {
        $usuario= new Usuario();
        if($usuario->existe($u)){
            $resp->call('yaExiste');
        } else {
            $usuario->setUsuario($u);
            $usuario->setPass($p);
            $usuario->create();
            $resp->call('alta');
        }
    }
    return $resp;
}

function añadir($nom, $nomc, $descrip, $pvp, $familia){ //Valida un producto en añadir/proponer.php y añade el nuevo producto a la base de datis
    $resp = jaxon()->newResponse();
    $producto=new Producto();
    if($producto->existe($nom)){
        $resp->alert("El producto ya existen");
    } else {
        $producto->setNombre($nom);
        $producto->setNombreCorto($nomc);
        $producto->setDescripcion($descrip);
        $producto->setPvp($pvp);
        $producto->setFamilia($familia);
        $producto->create();
        $resp->call('altaP');
    }
    return $resp;
}

//Por último, se regristran cada una de las funciones php que estarán disponibles para ejecutarse de forma asíncrona, mediante el método register()
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'validar');
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'vUsuario');
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'añadir');
