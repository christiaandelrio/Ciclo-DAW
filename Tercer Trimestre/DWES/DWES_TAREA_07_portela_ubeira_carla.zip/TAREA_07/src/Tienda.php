<?php
//CLASE DE TIENDA QUE HEREDA DE CONEXIÓN
require '../vendor/autoload.php'; 

class Tienda extends Conexion
{
    private $id;
    private $nombre;
    private $tlf;
    private $ciudad;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed 
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getTlf()
    {
        return $this->tlf;
    }

    /**
     * @param mixed 
     */
    public function setTlf($tlf)
    {
        $this->tlf = $tlf;
    }
     /**
     * @return mixed
     */
    public function getCiudad()
    {
        return $this->ciudad;
    }

    /**
     * @param mixed 
     */
    public function setCiudad($ciudad)
    {
        $this->ciudad = $ciudad;
    }

    //MÉTODOS
    /**
     * @param
     * @return array
     */
    public function getTiendas() { //Obtiene todos los ids de las tiendas ordenados por id
        $consulta = "select id from tiendas order by id";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al devolver las tiendas: " . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $tiendas[] = $fila->id;
        }
        return $tiendas;
    }

    /**
     * @param mixed
     * @return string|null
     **/
    public function getCiudadTienda(){ //Obtiene la ciudad de la tienda a partir del id de la tienda
        $consulta = "SELECT ciudad FROM tiendas WHERE id =:t";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->id
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar la tienda: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;
        return ($stmt->fetch(PDO::FETCH_OBJ))->ciudad;
    }

    /**
     * @param mixed
     * @return boolean
     **/
    public function existeTienda(){ //Devuelve true si la tienda existe a partir de su id
        $consulta = "SELECT * FROM tiendas WHERE id =:t";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->id
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar la tienda: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return false;
        return true;
    }

    /**
     * @param mixed
     * @return string
     **/
    public function getTiendaId() { //Obtiene el id de una tienda a partir de la ciudad de la tienda
        $consulta = "select id from tiendas where ciudad =:c";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':c' => $this->ciudad
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar la tienda: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;
        return ($stmt->fetch(PDO::FETCH_OBJ))->id;
    }

    /**
     * @param
     * @return array
     */
    public function getTiendasCiudad() {//Obtiene todas las ciudades de las tiendas, ordenadas por ciudad
        $consulta = "select ciudad from tiendas order by ciudad";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al devolver las tiendas: " . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $tiendas[] = $fila->ciudad;
        }
        return $tiendas;
    }

}
