<?php
//CLASE PRODUCTO QUE HEREDA DE CONEXIÓN
require '../vendor/autoload.php'; 
class Producto extends Conexion  {
    private $id;
    private $nombre;
    private $nombre_corto;
    private $pvp;
    private $familia;
    private $descripcion;

    /**
     * Producto constructor.
     */
    public function __construct()  {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getId()  {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)  {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre() {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getNombreCorto() {
        return $this->nombre_corto;
    }

    /**
     * @param mixed $nombre_corto
     */
    public function setNombreCorto($nombre_corto) {
        $this->nombre_corto = $nombre_corto;
    }

    /**
     * @return mixed
     */
    public function getPvp() {
        return $this->pvp;
    }

    /**
     * @param mixed $pvp
     */
    public function setPvp($pvp) {
        $this->pvp = $pvp;
    }

    /**
     * @return mixed
     */
    public function getFamilia() {
        return $this->familia;
    }

    /**
     * @param mixed $famila
     */
    public function setFamilia($familia)  {
        $this->familia = $familia;
    }

    /**
     * @return mixed
     */
    public function getDescripcion()  {
        return $this->descripcion;
    }

    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    //MÉTODOS
    /**
     * @param
     * @return
     */
    public function listadoProductos()  { //Para listar todos los productos ordenados por su id
        $consulta = "select * from productos order by id";
        $stmt = self::$conexion->prepare($consulta);
        
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos" . $ex->getMessage());
        }
        return $stmt;
    }

    /**
     * @param
     * @return string
     */
    public function getNombreById()  { //Obtener el nombre de un producto a partir de su id
        $consulta = "select nombre from productos where id=:i";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':i' => $this->id
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar el producto: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;
        return ($stmt->fetch(PDO::FETCH_OBJ))->nombre;
    }

    /**
     * @param
     * @return array
     */
    public function listadoFamilias()  { //Obtener todas las familias de productos ordenadas por familia
        $consulta = "select familia from productos order by familia";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos" . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $familias[] = $fila->familia;
        }
        return $familias;
    }
    
    /**
     * @param
     * @return boolean
     */
    public function existe($prod)  { //Se introduce un id de producto y devuelve un booleano de si existe o no ese producto en la base de datos
        $c = "select * from productos where nombre=:n";
        $stmt = Conexion::$conexion->prepare($c);
        $stmt->execute([':n' => $prod]);
        $filas = $stmt->rowCount();
        if ($filas == 0) return false;
        return true;
    }

    /**
     * @param
     * @return 
     */
    public function create() { //Añadir el producto a la tabla productos de la base de datos
        $i = "insert into productos (nombre, nombre_corto, descripcion, pvp, familia) values (:n, :nc, :d, :p, :f )";
        $stmt = Conexion::$conexion->prepare($i);

        try {
            $stmt->execute([
                'n' => $this->nombre,
                'nc' => $this->nombre_corto,
                'd' => $this->descripcion,
                'p' => $this->pvp,
                'f' => $this->familia
            ]);
        } catch (PDOException $ex) {
            die($ex->getMessage());
        }
    }

    /**
     * @param
     * @return array
     */
    public function listadoProductosId()  { //Listar los id de todos los productos ordenados por id
        $consulta = "select id from productos order by id";
        $stmt = self::$conexion->prepare($consulta);
        
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos" . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $ids[] = $fila->id;
        }
        return $ids;
    }
}
