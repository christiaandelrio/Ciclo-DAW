<?php

//CLASE VOTO QUE HEREDA DE CONEXIÓN
class Voto extends Conexion {
    public $id;
    public $cantidad;
    public $idPr;
    public $idUs;

    public function __construc() {
        parent::__construct();
    }

    /**
     * @param mixed $cantidad
     */
    public function setCantidad($cantidad): void  {
        $this->cantidad = $cantidad;
    }

    /**
     * @param mixed $idPr
     */
    public function setIdPr($idPr): void {
        $this->idPr = $idPr;
    }

    /**
     * @param mixed $idUs
     */
    public function setIdUs($idUs): void {
        $this->idUs = $idUs;
    }

    //MÉTODOS
    public function create() { //Crea un voto para un producto y usuario específico
        $i = "insert into votos(cantidad, idPr, idUs) values(:c, :ip, :iu)";
        $stmt = self::$conexion->prepare($i);

        try {
            $stmt->execute([
                ':c'  => $this->cantidad,
                ':ip' => $this->idPr,
                ':iu' => $this->idUs
            ]);
        } catch (PDOException $ex) {
            die("Error al guardar voto: " . $ex->getMessage());
        }
    }

    public function update() { //Actualiza un voto
        $yaexiste="select cantidad from votos where idPr =:ip and idUs =:iu";
        $stmt = self::$conexion->prepare($yaexiste);
        try {
            $stmt->execute([
                ':ip' => $this->idPr,
                ':iu' => $this->idUs
            ]);
        } catch (PDOException $ex) {
            die("Error al guardar voto: " . $ex->getMessage());
        }
        $cantidad = $stmt->fetch(PDO::FETCH_OBJ)->cantidad;
        if ($cantidad != $this->cantidad){//Si ya se emitió ese mismo voto, no lo actualiza
            $i = "update votos set cantidad =:c where idPr =:ip and idUs =:iu";
            $stmt2 = self::$conexion->prepare($i);
            try {
                $stmt2->execute([
                    ':c'  => $this->cantidad,
                    ':ip' => $this->idPr,
                    ':iu' => $this->idUs
                ]);
            } catch (PDOException $ex) {
                die("Error al guardar voto: " . $ex->getMessage());
            }
        return true;
        } else {
        return false;
        }
    }

    public function getTotalPuntos($p) { //Obtiene el total de puntos para un producto
        $c    = "select sum(cantidad) as total from votos where idPr=:p";
        $stmt = Conexion::$conexion->prepare($c);

        $stmt->execute([':p' => $p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->total;
    }

    public function getTotalVotos($p) { //Obtiene todos los votos de un producto
        $c    = "select count(*) as total from votos where idPr=:p";
        $stmt = Conexion::$conexion->prepare($c);

        $stmt->execute([':p'=>$p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->total;
    }

    public function getMedia($p) { //Obtiene la media de un producto
        $c    = "select avg(cantidad) as media from votos where idPr=:p";
        $stmt = Conexion::$conexion->prepare($c);

        $stmt->execute([':p' => $p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->media;
    }

    public function puedeVotar($u, $p)  { //Comprueba si ya existe un voto para un producto y usuario determinados
        $c    = "select * from votos where idPr=:p AND idUs=:u";
        $stmt = Conexion::$conexion->prepare($c);

        $stmt->execute([':p' => $p, ':u' => $u]);
        
        $filas = $stmt->rowCount();
        if ($filas == 0) return true;
        return false;
    }
}
