function envStock(){ //Creamos la función Js que llamará a la función PHP registrada con Jaxon de manera asíncrona
    let codT=document.getElementById("codT").value;
    jaxon_getStockTienda(codT);
}
