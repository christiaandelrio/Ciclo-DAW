<?php
$url = 'http://127.0.0.1/dwes_tema_06/TAREA_06/servidorSoap/servicio.wsdl';//Le pasamos la URL del servicio wsdl que hemos generado

try {
    //Creamos un nuevo cliente Soap pasándole la $url como parámetro
    $cliente = new SoapClient($url);
} catch (SoapFault $f) {
    die("Error en cliente SOAP:" . $f->getMessage());
}

$codP = 2;
$codT = 3;
$codF = 'CONSOL';

//funcion getPvp ----------------------------------------------------------------------------
$pvp = $cliente->__soapCall('getPvp', ['id' => $codP]);
//Realizamos una llamada a cada función del método mágico __soapCall()
$precio = ($pvp == null) ? "No existe es Producto" : $pvp;
//Mostramos el resultado devuelto
echo "Código de producto de Código $codP: $precio";

//funcion getFamilias -----------------------------------------------------------------------
echo "<br>Código de Familas";
$familias = $cliente->__soapCall('getFamilias', []);
echo "<ul>";
foreach ($familias as $k => $v) {
    echo "<code><li>$v</li></code>";
}
echo "</ul>";

//funcion getProductosFamila ----------------------------------------------------------------
$productos = $cliente->__soapCall('getProductosFamilia', ['cofF' => $codF]);
echo "<br>Productos de la Famila $codF:";
echo "<ul>";
foreach ($productos as $k => $v) {
    echo "<code><li>$v</li></code>";
}
echo "</ul>";

// funcion getStock -------------------------------------------------------------------------
$unidades = $cliente->__soapCall('getStock', ['codP' => $codP, 'codT' => $codT]);
echo "<br>Unidades del producto de código; $codP en la tienda de código: $codT: $unidades";

// funcion getStockProductosTienda ----------------------------------------------------------------------
$stocks = $cliente->__soapCall('getStockProductosTienda', ['codT' => $codT]);//Inicializamos una variable que contendrá todo el stock llamando al método mágico soapCall
echo "<br>Stock de productos de la tienda $codT:<br>";
echo "<ul>";
foreach($stocks as $k=>$v){
    echo"<li>$v</li>";
}
echo"</ul>";