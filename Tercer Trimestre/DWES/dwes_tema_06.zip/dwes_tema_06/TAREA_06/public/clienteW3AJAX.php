<?php
require '../src/Stockar.php';

use function Jaxon\jaxon;

if($jaxon->canProcessRequest())  $jaxon->processRequest();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type='text/javascript' src='../js/funciones.js'></script>
    <title>Document</title>
</head>
<body>
<form name='miForm' id="miForm" method='POST' action="javascript:void(null);" onsubmit="envStock();">
    <label for="codT">Introduce el número de una tienda</label>
    <input type="number" id="codT" name="codT">
    <button type="submit">Obtener Stock</button>
    <p id='respuesta'></p>   
</body>
</html>
<?php
// Preparamos Jaxon:
$jaxon = jaxon();//Instanciamos el singleton de Jaxon
echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n";//INyectamos el código de Jaxon