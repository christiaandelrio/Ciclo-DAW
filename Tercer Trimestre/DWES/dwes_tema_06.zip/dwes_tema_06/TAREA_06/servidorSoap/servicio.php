<?php
//Este primer servidor no tiene ningún documento WSDL
require '../vendor/autoload.php';

//$uri=$_SERVER['PHP_SELF'];
$uri = "http://127.0.0.1/dwes_tema_06/TAREA_06/servidorSoap";
$parametros = ['uri' => $uri];

try {
    $server = new SoapServer(NULL, $parametros);//Instanciamos un nuevo servidor soap sin url y con segundo parámtero que es la uri
    //
    $server->setClass('Clases\Operaciones');
    //ofrecerá las funciones implementadas en "src/Operaciones.php"
    $server->handle();
} catch (SoapFault $f) {
    die("error en server: " . $f->getMessage());
}
