<?php


namespace Clases;//Todas las clases de la carpeta src pertenecen al mismo namespace, tiene que estar en la primera linea

require '../vendor/autoload.php';//Archivo que nos carga todas las dependencias en la página

use PDO;

class Familia extends Conexion //Las clases de cada una de las columnas de la tabla de DB heredan de la clase Conexión
{
    private $cod;
    private $nombre;
    //Getters y setters
    /**
     * Familia constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getCod()
    {
        return $this->cod;
    }

    /**
     * @param mixed $cod
     */
    public function setCod($cod)
    {
        $this->cod = $cod;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @param
     * @return array
     */

    //Método para obtener las familias 
    public function getFamilias()
    {
        $consulta = "select cod from familias order by cod";//Consultamos los códigos de la tabla familias y los ordenamos por el código
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();//Ejecutamos la consulta
        } catch (\PDOException $ex) {
            die("Error al devolver las familias: " . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $familias[] = $fila->cod;//Metemos en un array los códigos
        }
        return $familias;//Retornamos el array de códigos
    }
}
