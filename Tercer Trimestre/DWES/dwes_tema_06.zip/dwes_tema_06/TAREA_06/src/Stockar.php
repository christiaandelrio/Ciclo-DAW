<?php
namespace Clases;//Establecemos primero el namespace

require '../src/Conexion.php';
require '../src/Stock.php';
require '../vendor/autoload.php';


use Jaxon\Jaxon; //La clase Jaxon nos permitirá hacer llamadas asíncronas a las funciones PHP
use function Jaxon\jaxon;

$jaxon = jaxon();//Instanciamos el singleton de Jaxon

// Opciones de configuración Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);
$jaxon->setOption('core.debug.verbose', false);

function getStockTienda($codT){
    $resp = jaxon()->newResponse();//Creamos una nueva respuesta de Jaxon
    $stock= new Stock();//Creamos un nuevo objeto Stock
    $stock->setTienda($codT);
    $stocks=$stock->getProductosUnidadesTienda();//Obtenemos los productos de esa tienda y sus unidades como un array de strings
    $resultado="<ul>";
    foreach($stocks as $k => $v){
        $resultado.="<li>".$v."</li>";
        }
        $resultado.="</ul>";
    $resp->assign("respuesta", "innerHTML", $resultado);//Asignamos al elemento del DOM con id respuesta la variable resultado
    return $resp;
}

$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'getStockTienda');
