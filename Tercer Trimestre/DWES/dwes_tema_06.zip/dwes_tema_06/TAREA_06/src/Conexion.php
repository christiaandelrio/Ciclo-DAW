<?php

namespace Clases;//Primero establecemos el namespace

use PDO;//La clase PDO representa una conexión entre PHP y un servidor de bases de datos.
use PDOException;

//Implementamos la clase que va a realizar la conexión con la base de datos
class Conexion
{
    protected static $conexion;


    public function __construct()//Constructor de la clase conexión
    {
        if (self::$conexion == null) {//Si el atributo de la clase (conexion) está vacío, llamamos al método de la clase que crea una nueva conexión
            self::crearConexion();
        }
    }

    public static function crearConexion()//Función que creará la conexión
    {
        $user = "gestor";
        $pass = "secreto";
        $base='tarea6';
        $dsn = "mysql:host=localhost;dbname=$base;charset=utf8mb4";
        
        try {
            self::$conexion = new PDO($dsn, $user, $pass);
            self::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $ex) {
            die("Error en la conexión: mensaje: " . $ex->getMessage());
        }
    }
}

