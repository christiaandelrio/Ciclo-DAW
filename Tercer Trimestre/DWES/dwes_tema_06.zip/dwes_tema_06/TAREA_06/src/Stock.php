<?php


namespace Clases;//Primero, el namespace

use PDO; //Usamos la clase que representa la conexión entre PHP y la base de datos

require '../vendor/autoload.php';//Cargamos la librerias de Composer

class Stock extends Conexion//La clase hereda de la Clase Conexion
{
    private $producto;
    private $tienda;
    private $unidades;
//Getters y setters
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getProducto()
    {
        return $this->producto;
    }

    /**
     * @param mixed $producto
     */
    public function setProducto($producto)
    {
        $this->producto = $producto;
    }

    /**
     * @return mixed
     */
    public function getTienda()
    {
        return $this->tienda;
    }

    /**
     * @param mixed $tienda
     */
    public function setTienda($tienda)
    {
        $this->tienda = $tienda;
    }

    /**
     * @return mixed
     */
    public function getUnidades()
    {
        return $this->unidades;
    }

    /**
     * @param mixed $unidades
     */
    public function setUnidades($unidades)
    {
        $this->unidades = $unidades;
    }
    /*
     * @param
     * @return int|null
     */
    public function getUnidadesTienda()//Método para obtener las unidades de un producto de una tienda determinada
    {
        $consulta = "select unidades from stocks where producto=:p AND tienda=:t";//Seleccionamos las unidades de la tabla stocks que se corresponden con el producto y la tienda introducida
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':p' => $this->producto,//Introducimos los parámetros
                ':t' => $this->tienda
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar los unidades: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;//Si la consulta está vacía devolvemos 0 unidades
        return ($stmt->fetch(PDO::FETCH_OBJ))->unidades;//Sino devolvemos las unidades del producto
    }

    public function getStockTienda(){//Método para obtener el stock de una tienda
        $consulta = "select unidades from stocks where tienda=:t";//Se seleccionan las unidades de una tienda que se pasa por parámetro
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->tienda//Introducimos el parámetro
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar los unidades: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return null;//Devolvemos null si la consulta está vacía
        return $stmt->fetch(PDO::FETCH_OBJ)->unidades;//Sino devolvemos las unidades de la tienda
    }
    public function getProductosUnidadesTienda(){//Método por el que obtenemos todos los productos y su stock en un tienda que pasamos por parámetro
        $consulta = "select producto, unidades from stocks where  tienda=:t";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->tienda//Le pasamos la tienda que se ha configurado en el atributo tienda del objeto Stocks
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar los unidades: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {//Cada fila es un objeto Stock completo (producto, unidades y tienda)
            $id= $fila->producto;//Obtenemos el id del producto en la tabla stocks
                $consultaId="select nombre from productos where id=:i";//Realizamos una nueva consulta del nombre del id obtenido en la tabla productos
                $stmtId = self::$conexion->prepare($consultaId);//Ejecutamos una nueva consulta
                try {
                    $stmtId->execute([
                        ':i' => $id//Le pasamos el id obtenido en la consulta
                    ]);
                } catch (\PDOException $ex) {
                    die("Error al recuperar los unidades: " . $ex->getMessage());
                }
                $productos=$stmtId->fetch(PDO::FETCH_OBJ)->nombre;//Introducimos el nombre en la variable productos
            $stocks=$fila->unidades;//Obtenemos las unidades de ese producto
            $stockTienda[] = "Producto ".$productos.": ".$stocks." unidades.";//Guardamos en un array el string con el nombre de los productos y su stock
        }
        return $stockTienda;
    }
}
