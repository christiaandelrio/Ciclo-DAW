<?php


namespace Clases;//Establecemos primero el namespace

require '../vendor/autoload.php';//Cargamos las librerías de composer

use PDO; //La clase PDO representa una conexión entre PHP y un servidor de bases de datos.

class Producto extends Conexion//Como todas las clases de la tabla, hereda de la clase Conexión
{
    private $id;
    private $nombre;
    private $nombre_corto;
    private $pvp;
    private $famila;
    private $descripcion;

//Getters y setters
    /**
     * Producto constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getNombreCorto()
    {
        return $this->nombre_corto;
    }

    /**
     * @param mixed $nombre_corto
     */
    public function setNombreCorto($nombre_corto)
    {
        $this->nombre_corto = $nombre_corto;
    }

    /**
     * @return mixed
     */
    public function getPvp()
    {
        return $this->pvp;
    }

    /**
     * @param mixed $pvp
     */
    public function setPvp($pvp)
    {
        $this->pvp = $pvp;
    }

    /**
     * @return mixed
     */
    public function getFamila()
    {
        return $this->famila;
    }

    /**
     * @param mixed $famila
     */
    public function setFamila($famila)
    {
        $this->famila = $famila;
    }

    /**
     * @return mixed
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }

    /*
     * @param string $codF
     * @return array|null
     */
    public function productoFamilia($codF)//Método que devuelve los productos de una familia pasada por parámetro 
    {
        $consulta = "select nombre from productos where familia=:f";//Consultamos los nombres de los productos cuya familia sea la pasada por parámetro
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([':f' => $codF]);//Pasamos a la consulta el parámetro introducido
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos x famila: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return null;//Si no devuelve la consulta ningún valor devuelve null
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $productos[] = $fila->nombre;//Obtenemos los nombres de los productos y los guardamos en un array de productos
        }
        return $productos;
    }
    /*
     * @param
     * @return float|null
     */
    public function getPrecio()//Método para obtener el precio de un producto por su id
    {
        $consulta = "select pvp from productos where id=:i";//Consultamos el precio de la tabla productos que coincidan con el id introducido
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([':i' => $this->id]);//Introducimos el parámtero id
        } catch (\PDOException $ex) {
            die("Error al recuperar los productos x famila: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return null;
        return ($stmt->fetch(PDO::FETCH_OBJ))->pvp;//Devuelve el precio del producto
    }
}
