<?php
    session_start();

	//Al iniciar borramos los mensajes de error
	$error= false;


	//En el login.php habíamos definido un nombre de usuario en la sesión que ahora vamos a mostrar en esta página:
	if(isset($_SESSION['nombre'])){
		$nombre = $_SESSION['nombre'];
	}

	//---------------------  Lógica para persistir en BD usando Jaxon ---------------------------------------------------

	//TODO: JAXON
	// Indicamos el directorio del vendor
	require (__DIR__ . '/vendor/autoload.php');

	//Importamos Jaxon
	use Jaxon\Jaxon;
	use Jaxon\Response\Response;
	use function Jaxon\jaxon;

	// Obtenemos una referencia al objeto singleton jaxon
	$jaxon = jaxon();

	//Esta es la función que luego emplearemos en el botón al hacer onclick como jaxon_transferirDatos()
	function transferirDatos(){

		$respuesta = jaxon()->newResponse();

		//Comprobamos si tenemos algún texto almacenado en la sesión:
		if(!empty($_SESSION['textos'])){
			//Abrimos la conexión a la base de datos:
			require_once 'conexion.php';

			//Recorremos todo el array de palíndromos con un foreach, cada elemento es una $fila ["si/no", "texto", "transferida"]
			foreach($_SESSION['textos'] as &$fila){

				//En el caso de que en la posición 2 del array no tengamos "transferido", quiere decir que se trata de un nuevo elemento y por tanto lo agregamos a la BD.
				if(!isset($fila[2])){
					//Agregamos la característica de "transferido" a los nuevos elementos que no habían sido trasnferidos previamente:
					$fila[2] = "transferido";

					//Creamos la consulta para almacenar en la base de datos:
					//Insertamos en la tabla palindromos: id int auto_increment primary key,    usuario varchar(20) NOT NULL,    frase varchar(500) not null,    esPalindromo int not null,
					$consulta = "insert into palindromos(usuario, frase, esPalindromo) values(:u, :f, :p)";

					//Preparamos la consulta (Aquí hay que fijarse como le llamamos a la conexión en conexion.php, en este caso $conProyecto):
					$stmt = $conProyecto->prepare($consulta);
				
					//Ejecutamos la consulta:
					try {
						$stmt->execute([
							':u' => $_SESSION['nombre'], //Cogemos el nombre de usuario de la sesión
							':f' => $fila[1], //Cogemos el texto del array
							':p' => $fila[0] == "no" ? 0 : 1 //Ojo. Si es palíndromo o no se guarda con un int y no como texto. Hay que fijarse en el sql que proporciona
						]);

					} catch (PDOException $ex) {
						cerrarTodo($conProyecto, $stmt);
						$respuesta->assign('resultadoPersistir', 'innerHTML', "<p style='color: black; background: red;'>Error de conexión a base de datos</p>");
						return $respuesta;
					}
				}
			}

			//Cerramos la conexión a la base de datos
			cerrarTodo($conProyecto, $stmt);

			//Si todo fue bien devolvemos un mensaje de éxito que se mostrará en <div id="resultadoPersistir"></div>
			$respuesta->assign('resultadoPersistir', 'innerHTML', "<p class='alert alert-success my-2'>Éxito de carga</p>");
		}else{
			//Si hubo un error devolvemos un mensaje de error que se mostrará en <div id="resultadoPersistir"></div>
			$respuesta->assign('resultadoPersistir', 'innerHTML', "<p class='alert alert-warning my-2'>No hay nada que persistir</p>");
		}

		//Devolvemos la respuesta
		return $respuesta;
	}

	// TODO: Registramos la funcion con Jaxon
	$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'transferirDatos');


	// TODO: Dejamos todo preparado para procesar las solicitudes Jaxon entrantes
	if($jaxon->canProcessRequest())  $jaxon->processRequest();



	//---------------------  Lógica para comprobar textos, palíndromos, almacenar en sesión, etc.------------------------
	if(!isset($_SESSION['textos'])){
		//Si no está definida la variable de sesión "textos", la inicializamos con como un un array vacío
		$_SESSION['textos'] = array();
	}

    if(isset($_POST['enviar'])){
		//Capturamos el texto, eliminando al principio y al final los espacios
		$texto = trim($_POST['texto']);

		//Solicite del usuario una frase que solo tenga letras minúsculas sin acentuar y sin signos de puntuación ni otro carácter extraño (es decir, abcdefghijklemnñopqrstuvwxyz).
		if (preg_match ("/^[a-z\s]+$/", $texto)) {
			//Método largo para invertir una cadena
			// //Divimos la cadena de texto
			// $texto_dividido = str_split($texto, 1);
			// //Invertimos las letras
			// $array_invertido = array_reverse($texto_dividido);
			// //Volvemos a unir las letras obteniendo la palabra alrevéas
			// $texto_invertido = implode("", $array_invertido);


			//Si queremos comprobar si es palíndromo sin espacios intermedios:
			// $fraseNormalSinEspacios    = str_replace(' ', '', $texto);
			// $fraseInvertidaSinEspacios = strrev($fraseNormalSinEspacios);

			//Forma más rápida para invertir un string:
			$texto_invertido = strrev($texto);

			//Si pasa la validación hacemos que el mensaje de error desaparezca;
			$error = false;

			//Si el texto introducido es igual a su inverso es que es palíndromo
			if($texto == $texto_invertido){
				//La almaceno en la variable $palindromo para mostrarlo más abajo
				$palindromo = $texto;
				
				//Si es palíndromo guardo en la sesión el texto con su valor "si"
				if(isset($_SESSION['textos'])){
					// Agregamos el nuevo valor con el resultado de si es o no palíndromo
					$_SESSION['textos'][] = ['sí', $texto];
				}
			}else{
				$no_palindromo = $texto;
				if(isset($_SESSION['textos'])){
					// Agregamos el nuevo valor con el resultado de si es o no palíndromo
					$_SESSION['textos'][] = ['no', $texto];
				}
			}
		}else{
			$error = true;
		}
    };

	//Botón para resetear
	if(isset($_POST['resetear'])){
		// Si se pulsa el botón de vaciar, se vaciará la sesión.
		$_SESSION['textos'] = [];
	}
?>


<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Pregunta 2</title>
		<!-- Bootstrap -->
		<link
			href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
			rel="stylesheet"
			integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD"
			crossorigin="anonymous"
		/>
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<div id="container" class="p-4">

			<!-- Mostramos el nombre de usuario que recibimos desde login.php -->
			<?php 
				if(isset($nombre)){
					echo "<p style='position: absolute; top: 0; right: 20px;'>Usuario logeado: $nombre</p>";
				}
			?>

            <form action="" method="POST">
                <p>Introduzca una frase con palabras con sólo letras minúsculas sin acentuar:</p>
                <input
                    class="form-control mb-4"
                    type="text"
                    id="texto"
                    name="texto"
                    placeholder="Introduce una frase"
                />
				<!-- si la frase no cumple se le indicará al usuario por qué, y se solicitará de nuevo su introducción. -->
				<?php 
					if($error === true){
						echo '<div class="alert alert-danger my-2">El texto solamente debe contener letras minúsculas sin acentos</div>';
					}
				?>
                <div class="mb-2">
                    <button class="btn btn-primary" name="enviar" id="enviar">Enviar</button>
                    <button class="btn btn-danger" name="resetear" id="resetear">Borrar</button>
                </div>
            </form>

			<!-- TODO: Botón para persistir -->
			<button class="btn btn-success" onclick="jaxon_transferirDatos();return false;" />Persistir</button>
			<div id="salidas"></div>

			<!--TODO: Salidas de la función de persistir -->
			<div id="resultadoPersistir"></div>

			<?php
				if(isset($texto_invertido)){
				//si la frase valida correctamente: ◦ se escribirá la frase del revés ◦ se indicará si la frase es un palíndromo o si no lo es.
				echo "<p>Escrita alrevés: $texto_invertido </p>";
				}

				//Si el texto es palíndromo mostramos la siguiente frase:
				if(isset($palindromo)){
					echo "<p>$palindromo si es palíndromo!!!</p>";
				}

				//Si el texto no es palíndromo mostramos la siguiente frase:
				if(isset($no_palindromo)){
					echo "<p>$no_palindromo no es palíndromo</p>";
				}
		
				if(empty($_SESSION['textos'])) { ?>
                <div class="alert alert-warning my-2">No hay textos por el momento</div>
                <?php } else { ?>
					<p>
						Frases probadas hasta el momento:
					</p>

					<table>
						<tr>
							<th>Palíndromo</th>
							<th>Frase</th>
						</tr>

						<?php foreach($_SESSION['textos'] as $fila) : ?>
						<tr>
							<!-- El elemento 0 representa a si o no -->
							<td><?=$fila[0]?></td> 
							<!-- El elemento 1 es en el que tenemos guardadas las frases -->
							<td><?=$fila[1]?></td> 
						</tr>
						<?php endforeach; ?>
					</table>
                <?php } ?>
		</div>
	</body>

	<?php
		//TODO: 5. Insertamos el codigo javascript de Jaxon javascript al final de la página
		echo $jaxon->getJs();
		echo $jaxon->getScript();
	?>      
</html>
