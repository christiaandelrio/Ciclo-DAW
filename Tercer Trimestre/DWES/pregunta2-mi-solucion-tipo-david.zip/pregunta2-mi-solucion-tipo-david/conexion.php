<?php
$host = "localhost";
$db   = "pregunta2";
// $user = "adminpregunta2"; //TODO: Tendríamos que añadir este usuario nuevo a la base de datos
$user = "gestor"; //TODO: Otra alternativa es la de poner un usuario que ya tengamos definido
$pass = "secreto";
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
try {
    $conProyecto = new PDO($dsn, $user, $pass);
    $conProyecto->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $ex) {
    die("Error en la conexión: mensaje: " . $ex->getMessage());
}

function cerrar(&$con){
    $con = null;
}
function cerrarTodo(&$con, &$st){
    $st = null;
    $con = null;
}


