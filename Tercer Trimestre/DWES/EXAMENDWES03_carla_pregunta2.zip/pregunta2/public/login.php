<?php
session_start(); //Iniciamos sesión

require '../src/Usuarios.php';//Pagina con la funcionalidad para crear y validar los usuarios


//Método para gestionar errores
function error($mensaje)
{
    $_SESSION['error'] = $mensaje;
    header('Location:login.php');
    die();
}

//Método para validar la introducción del nombre de usuario
function validarNombre($nombre){
    return preg_match("/^[a-zñÑA-Z]{1,10}/i", $nombre);
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Login</title>
</head>

<body style="background:silver;">
<?php
if (isset($_POST['login'])) { //Si se pulsa el botón de "Login"
    $nombre = trim($_POST['usuario']);//Se pasa el nombre de usuario sin espacios al principio y al final
    $pass = trim($_POST['pass']);//Se pasa la contraseña sin espacios al inicio y al final
    
    if (strlen($nombre) == 0 || strlen($pass) == 0) {
        error("Error, El nombre o la contraseña no pueden contener sólo espacios en blancos.");
    } else {
        if(!validarNombre($nombre)){
            error("Error, El nombre debe contener por los menos 10 caracteres.");
        }
    }

    //creamos el sha256 de la contraseña que es como se almacena en mysql
    $pass1 = hash('sha256', $pass);
    $usuario = new Usuarios();//Creamos un usuario
    $usuario->setUsuario($nombre);//establecemos nombre y password del objeto Usuario
    $usuario->setPass($pass1);
    $validar=$usuario->validarUsuario();//Comprobamos si existe en la base de datos
    if(!$validar){
        error("Error, Nombre de usuario o password incorrecto");
    }
    $_SESSION['nombre'] = $nombre; //Si existe en la base de datos metemos el nombre del usuario en una variable de sesión nombre
    header('Location:pagina1.php');//Dirige a la página1.php
} else {
    ?>
    <div class="container mt-5">
        <div class="d-flex justify-content-center h-100">
            <div class="card">
                <div class="card-header">
                    <h3>Iniciar sesión</h3>
                </div>
                <div class="card-body">
                    <form name='login' method='POST' action='<?php echo $_SERVER['PHP_SELF']; ?>'>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="usuario" name='usuario' required>

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" class="form-control" placeholder="contraseña" name='pass' required>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Login" class="btn float-right btn-success" name='login'>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='mt-3 text-danger font-weight-bold text-lg'>";
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                echo "</div>";
            }
        ?>
    </div>
<?php } ?>
</body>

</html>