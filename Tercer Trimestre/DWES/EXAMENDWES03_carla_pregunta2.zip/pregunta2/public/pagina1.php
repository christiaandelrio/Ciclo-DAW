<?php
session_start(); //Iniciamos la sesión para trabajar con sesiones

require '../vendor/autoload.php';//Se cargan las librerías de composer


//Preparamos Jaxon:
require '../src/Guardar.php';//php con la función registrada con jaxon
use function Jaxon\jaxon;
if($jaxon->canProcessRequest())  $jaxon->processRequest();//Para procesar la solicitud


//Método para validar frase mediante una expresión regular
function validarFrase($frase){
    return preg_match("/^[a-zñ\s]+$/", $frase); //Devuelve el resultado de comparar la expresión regular con la variable frase que hemos introducido como parámtero
}

//Método para imprimir la frase del revés
function reves($frase){
    return strrev($frase);
}

//Método para validar si la frase es o no un palíndromo
function palindromo($frase){
    $fraseArray=explode(" ", $frase); //Guardamos en un array cada palabra de la frase (el separador es un espacio)
    $fraseNueva=""; //Iniciamos una variable en la que vamos a guardar todas las palabras del array anterior
        foreach($fraseArray as $palabra)
        {
            trim($palabra);//Por cada palabra del array frase, quitamos los espacios del inicio y del final y la añadimos a la variable $fraseNueva
            $fraseNueva .= $palabra; 
        }
        if($fraseNueva == strrev($fraseNueva)){//Si la frase al derecho y la frase del revés son iguales
            $palindromo=true;//Se devuelve true
        } else {
            $palindromo=false;//Sino se devuelve false;
        }
    return $palindromo;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="../js/guardar.js"></script>
    <title>pregunta2</title>
</head>
<body style="font-family: monospace">
<?php
    if(isset($_SESSION['nombre'])){ //Si se ha validado el usuario (en login.php) muestra el nombre de usuario y el saludo
        $usuario=$_SESSION['nombre'];
    ?>
    <p>Buenas tardes <?php echo $usuario?></p>
    <?php
    } else {
        $usuario=null;//Sino, no muestra el saludo
    }
    //Inicializamos las variables
    $frase="";
    $esPalindromo="";
    $contador=1;//Contador que nos servira para establecer la id de cada elemento del array de sesión 'frases'
    ?>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>"  method="get">
        <p>
            <label for="frase">Introduzca una frase sólo con letras minúsculas sin acentuar</label>
            <input type="text" id="frase" name="frase" style="background-color:grey;"/>
        </p>
        <button id="enviar" name="enviar" type="submit">Enviar</button>      
        <button id="borrar" name="borrar">Borrar</button> 
    </form>
    <?php
    if(isset($_GET['enviar'])){ //Si se pulsa "Enviar"
        $frase = $_GET['frase'];
        if($frase=="" || strlen($frase)==0){ //Si la frase está vacia o la longitud del string es menor o igual que cero
            echo "<p style='color:red;'>Por favor, introduzca una frase</p>";
        } else {
            if(!validarFrase($frase)){ //Si no es válida la frase se muestra el correspondiente mensaje
                echo "<p style='color:red;'>La frase solo puede contener letras minúsculas y sin signos de puntuación</p>";
            } else {
                //Si la frase es válida, es decir, encaja con la expresión regular
                $reves=reves($frase);//Ponemos la frase del revés (incluyendo los espacios)
                echo "<p id='reves' style='background-color:aqua; width:300px'>La frase al revés es: ".$reves."</p>";
                if(!palindromo($frase)){
                    $esPalindromo="No";
                } else {
                    $esPalindromo="Sí";
                }
                //Imprimimos si es o no paíndromo
                echo "<p id='palindromo' style='background-color:aqua;  width:300px'>".$esPalindromo." es un palíndromo</p>";
                //Agregamos el nuevo valor al array
                $_SESSION['frases'][$frase] = $esPalindromo; //Guardamos en la variable de sesión frases, la frase como clave y el resultado del palíndromo como valor
                //Mostramos un botón que llamará a la funcion Js, pasando por parámteros el usuario, frase y si es o no palíndromo actuales
                echo"<p style='background-color:aqua; width:220px'>Frases probadas hasta ahora:</p>";  
                echo"<table>";
                if(count($_SESSION['frases'])!==0){
                    foreach($_SESSION['frases'] as $fr=>$pal){//Por cada elemento guardado, imprime en una misma fela, en cada celda de una tabla, la frase y si es o no palíndromo
                    echo "<tr>";
                    echo"<td style='background-color:aqua; width:300px'>  ".$pal." es un palíndromo  </td>";
                    echo"<td style='background-color:aqua; width:300px'>  ".$fr."  </td>";
                    //Antes de pasar los parametros parseamos la variable esPalindromo  en no a false(0) y si a true (1), para que los guarde bien en la base de datos, ya que esta columna es de tipo int y no string
                    if($pal=="No"){
                        $pal=false;
                    } else {
                        $pal=true;
                    }
                    echo "<td><button id=\"persistir_".$contador."\" style='display:inline' onclick=\"guardarFrase('{$usuario}','{$fr}','{$pal}','{$contador}')\">Persistir</button></td>";
                    echo "</tr>";
                    $contador++;//Por cada lemento que creamos aumentamos en uno el contador
                    }
                echo"</table>";
                }
            }
        }     
        
    }
    if(isset($_GET['borrar'])){ //Si se pulsa el botón "borrar"
        $frase=""; //Se borra la frase actual
        $esPalindromo="";//Se borra el resultado de palíndromo
        $contador=1;
        unset($_SESSION['frases']); //Borramos la variable de sesión que guarda las frases que introducimos
    }
    ?>           
</body>
<?php
    $jaxon = jaxon();
    echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n";
?>
</html>