<?php
require '../vendor/autoload.php';//Se cargan las librerías de composer
require '../src/Palindromos.php';//Clase con funcionalidad para crear y validar palíndromos

use Jaxon\Jaxon;
use function Jaxon\jaxon;

$jaxon = jaxon(); //Instanciamos el singleton de Jaxon

// Opciones de configuración Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);
$jaxon->setOption('core.debug.verbose', false);

//Método para guardar un palíndromo (si este no existe en la base de datos)
function guardar($usuario,$frase,$esPalindromo,$contador){
        $resp = jaxon()->newResponse();//Creamos una nueva respuesta de Jaxon
        $palindromo= new Palindromos();//Creamos un nuevo objeto Palindromos
        $palindromo->setUsuario($usuario);//Se establece el usuario
        $palindromo->setFrase($frase);//Se establece la frase
        $palindromo->setPalindromo($esPalindromo);//Se establece si es o no palíndromo
        if($palindromo->existePalindromo()){//Si existe el palindromo
            $resp->call('repetido', $contador);//Se llama a la función de Js pasando por parámetro el contador de palíndromo que ya existe
        } else {
            $palindromo->create();//Sino existe, lo creamos y llamamos a la función Js para que alerte de que se ha añadido y esconda el botón de guardar
            $resp->call('añadido', $contador); //Llamamos a la función Js y le pasamos la frase como parámetro
        }
        return $resp;
    }

$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'guardar');//Registramos la función en Jaxon
