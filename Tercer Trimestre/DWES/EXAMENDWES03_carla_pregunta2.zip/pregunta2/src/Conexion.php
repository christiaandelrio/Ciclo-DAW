<?php

class Conexion
{
    protected static $conexion;


    public function __construct()
    {
        if (self::$conexion == null) {
            self::crearConexion();
        }
    }

    public function getConexion()
    {
        return $this->conexion;
    }

    public static function crearConexion()
    {
        $host = "localhost";
        $db = "pregunta2";
        $user = "adminpregunta2";
        $pass = "secreto";
        $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
        
        try {
            self::$conexion = new PDO($dsn, $user, $pass);
            self::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $ex) {
            die("Error en la conexión: mensaje: " . $ex->getMessage());
        }
    }
    public static function cerrar(&$con){
        $con = null;
    }
    public static function cerrarTodo(&$con, &$st){
        $st = null;
        $con = null;
    }
}
