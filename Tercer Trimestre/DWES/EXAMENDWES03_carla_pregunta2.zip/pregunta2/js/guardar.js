function guardarFrase(usuario, frase, esPalindromo, contador){
    //LLamamos a la función registrada de Jaxon para guardar el palíndromo
    jaxon_guardar(usuario,frase,esPalindromo, contador);
    // anulamos la acción por defecto del formulario:
    return false;
}

function añadido(contador){ //Función que eliminará el botón de "Persistir" y alertará de que se ha añadido el palíndromo a la base de datos
    let id= "persistir_" + contador;//Construimos el id del botón persistir que será distinto para cada elemento
    let botonPersitir=document.getElementById(id); //Contruimos el id con la frase que pasamos por parámetro
    botonPersitir.style.display="none";//Lo escondemos
    alert("Se ha añadido la entrada");
}

function repetido(contador){
    let id= "persistir_" + contador;
    let botonPersitir=document.getElementById(id); //Contruimos el id con la frase que pasamos por parámetro
    botonPersitir.style.display="none";//Lo escondemos
    alert("Esta entrada ya existe");
}

