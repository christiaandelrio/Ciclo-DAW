<?php
require '../src/Conexion.php'; 
class Usuarios extends Conexion{
    public $usuario;
    public $pass;
    
    public function __construc() {
        parent::__construct();
    }
    public function setUsuario($usuario): void  {
        $this->usuario = $usuario;
    }
    public function setPass($pass): void  {
        $this->pass = $pass;
    }
    

    public function validarUsuario(){ //Método para validar si existe un usuario en la base de datos
        $consulta = "select * from usuarios where usuario=:u AND pass=:p";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':u'  => $this->usuario,
                ':p' => $this->pass
            ]);
        } catch (PDOException $ex) {
            die("Error al consultar la base de datos: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) {//Si no se encuentra ningún elemento no existe
            return false; 
        } else{
            return true;
        }
    }

    public function create() { //Método para crear un nuevo usuario en la base de datos
        $consulta = "insert into usuarios (usuario, pass) values (:u, :p)";
        $stmt = self::$conexion->prepare($consulta);

        try {
            $stmt->execute([
                ':u'  => $this->usuario,
                ':p' => $this->pass
            ]);
        } catch (PDOException $ex) {
            die("Error al crear el usuario: " . $ex->getMessage());
        }
    }
}