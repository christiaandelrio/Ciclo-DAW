<?php 
require '../src/Conexion.php'; 
class Palindromos extends Conexion{
    
    public $usuario;
    public $frase;
    public $esPalindromo;
    
    public function __construc() {
        parent::__construct();
    }
    public function setFrase($frase): void  {
        $this->frase = $frase;
    }
    public function setUsuario($usuario): void  {
        $this->usuario = $usuario;
    }
    public function setPalindromo($esPalindromo): void  {
        $this->esPalindromo = $esPalindromo;
    }

    
    public function existePalindromo(){ //Método para validar si existe un palindromo en la base de datos
        $consulta = "select * from palindromos where usuario=:u and frase=:f and esPalindromo=:e";
        $stmt = self::$conexion->prepare($consulta);

        try {
            $stmt->execute([
                ':u'  => $this->usuario,
                ':f' => $this->frase,
                ':e' => $this->esPalindromo
            ]);
        } catch (PDOException $ex) {
            die("Error al crear el palíndromo: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return false;
        return true;
    }
    
    public function create() { //Método para crear un nuevo palíndromo
        $consulta = "insert into palindromos(usuario, frase, esPalindromo) values(:u, :f, :e)";
        $stmt = self::$conexion->prepare($consulta);

        try {
            $stmt->execute([
                ':u'  => $this->usuario,
                ':f' => $this->frase,
                ':e' => $this->esPalindromo
            ]);
        } catch (PDOException $ex) {
            die("Error al crear el palíndromo: " . $ex->getMessage());
        }
    }

}