function enviarCiudad(ciudad){ 
    jaxon_calcularClima(ciudad);//LLamamos a la función de Jaxon registrada, pasando como parámtero la ciudad de la tienda obtenida
    return false;
}


