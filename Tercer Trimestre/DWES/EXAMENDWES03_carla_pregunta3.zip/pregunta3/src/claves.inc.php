<?php
// Estas son las claves para las APIs.
//Se añadirían a cada página php en las que se necesiten con el método require
$keyAEMET = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJtZXJlZGl0aW5oYUBnbWFpbC5jb20iLCJqdGkiOiI0OTExM2E1NC1iNzUwLTQ3YzQtYmRmNC00YTBmMmEzZGZmMzYiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTY4NDczNDU4MywidXNlcklkIjoiNDkxMTNhNTQtYjc1MC00N2M0LWJkZjQtNGEwZjJhM2RmZjM2Iiwicm9sZSI6IiJ9.45ki2ICgHLJgbdT_0pDZy9AFQOyc5bn4IBUk_Bu08jM";

$keyOpenWeatherMap  = '51e83375a3a499800e5613d9eda1e766';  

$keyBing = "AmhbPAMKfXZ1EOzAkqZm49NrnpdRhNoFPZGolc0-SvFR-kGkKLKb5DPKbIGhurYC";  

//Son independientes para cada proyecto
$googleClientId     = '418238158215-qkog6lncisl9t7chnda5avq6ql3u8elk.apps.googleusercontent.com'; 
$googleClientSecret = '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'; 

/*Activación de Google APIs
1 - Registro en Google Cloud
2 - Creación de nuevo proyecto (PhpGoogleAPIs) y habilitar en "APIs y servicios habilitados" la API "Google Tasks"
3 - COnfiguración de pantalla de consentimiento:
  - Establecer tipo de usuario Externo (Importante que coincida "Página principal de la aplicación" - http://127.0.0.1/.../probarTasks.php)
  - Establecer permisos de acceso en "Agregar o quitar permisos" y dar pemirso a "Google Tasks API" de crear, editar, organizar y borrar tareas
  - Añadir usuarios de prueba.
4 - Creamos credenciales de tipo "ID de cliente OAuth" y de tipo "Aplicación Web"; y editam,os URI autorizado de Javascript y de redireccionamiento válido
    (http://localhost/.../probarTasks.php)
5 - Nos generará las claves que opcionalmente podemos decargar en formato json
*/

