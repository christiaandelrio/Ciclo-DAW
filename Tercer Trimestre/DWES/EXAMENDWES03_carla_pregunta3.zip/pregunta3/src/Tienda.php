<?php
// EXAMEN 3º AVALIACION DWES

namespace Clases;

require '../vendor/autoload.php'; 

use \PDO;

class Tienda extends Conexion
{
    private $id;
    private $nombre;
    private $tlf;
    private $ciudad;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $Id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed 
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getTlf()
    {
        return $this->tlf;
    }

    /**
     * @param mixed 
     */
    public function setTlf($tlf)
    {
        $this->tlf = $tlf;
    }
     /**
     * @return mixed
     */
    public function getCiudad()
    {
        return $this->ciudad;
    }

    /**
     * @param mixed 
     */
    public function setCiudad($ciudad)
    {
        $this->ciudad = $ciudad;
    }



    /**
     * @param
     * @return array
     */
    public function getTiendas()
    {
        $consulta = "select id from tiendas order by id";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al devolver las tiendas: " . $ex->getMessage());
        }
        while ($fila = $stmt->fetch(PDO::FETCH_OBJ)) {
            $tiendas[] = $fila->id;
        }
        return $tiendas;
    }

    /**
     * @param mixed
     * @return string|null
     **/
    public function getCiudadTienda(){ //Función para obtener la ciudad de la tienda
        $consulta = "SELECT ciudad FROM tiendas WHERE id =:t";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->id
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar los unidades: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return 0;
        return ($stmt->fetch(PDO::FETCH_OBJ))->ciudad;
    }

    public function existeTienda(){
        $consulta = "SELECT * FROM tiendas WHERE id =:t";
        $stmt = self::$conexion->prepare($consulta);
        try {
            $stmt->execute([
                ':t' => $this->id
            ]);
        } catch (\PDOException $ex) {
            die("Error al recuperar los unidades: " . $ex->getMessage());
        }
        if ($stmt->rowCount() == 0) return false;
        return true;
    }

}
