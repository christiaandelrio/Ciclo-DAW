<?php
//EN esta página se implementan los métodos que registraremos en Jaxon

require '../vendor/autoload.php';//Se cargan las librerías de composer

use Jaxon\Jaxon;
use function Jaxon\jaxon;

$jaxon = jaxon(); //Instanciamos el singleton de Jaxon

// Opciones de configuración Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);
$jaxon->setOption('core.debug.verbose', false);

function calcularClima($ciudad){
    $resp = jaxon()->newResponse();//Creamos una nueva respuesta de Jaxon

    $curl = curl_init();//Inicia la sesión en la librería curl
    require '../src/claves.inc.php';//Se carga la clase con las claves de las API

    //Buscamos la longitud y latitud de la ciudad
    $urlBase1 = 'http://api.openweathermap.org/geo/1.0/direct?'; //Geolocalización
    $url1   = $urlBase1 . 'q=' . $ciudad . '&limit=5' . "&appid=" .  $keyOpenWeatherMap;//Metemos la url, la ciudad y las claves
    curl_setopt_array($curl, array(//Establecemos las opciones para hacer el curl
    CURLOPT_URL => $url1,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache"
    ),
    ));
    $response = curl_exec($curl);//Ejecutamos el curl
    $err = curl_error($curl);
    curl_close($curl);//Cerramos el curl

    if ($err) {
    echo "cURL Error #:" . $err;
    } else {
    $salida = json_decode($response, true);
    $lat=$salida[0]['lat'];//Obtenemos la latitud y la longitud de la ciudad, del curl1
    $lon=$salida[0]['lon'];
    }

    //Buscamos la predicción del tiempo con latitud y longitud hayadas
    $curl = curl_init();//Inicia la sesión en la librería curl
    require '../src/claves.inc.php';//Se carga la clase con las claves de las API
    $urlBase2 = 'https://api.openweathermap.org/data/2.5/weather?'; //Previsión de tiempo    
    $url2   = $urlBase2 . '&lat=' . $lat . "&lon=" . $lon . "&units=metric". "&lang=es". "&appid=" . $keyOpenWeatherMap;//Metemos la latitud y longitud
    curl_setopt_array($curl, array(//Establecemos las opciones para hacer el curl
    CURLOPT_URL => $url2,//La búsqueda que se establece es para la previsión del tiempo por latitud y longitud
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache"
    ),
    ));
    $response = curl_exec($curl);//Ejecutamos el curl
    $err = curl_error($curl);
    curl_close($curl);//Cerramos el curl

    if ($err) {
    echo "cURL Error #:" . $err;
    } else {
    $tiempo = json_decode($response, true);//Obtenemos los valores del clima del curl2
    $datosClima="<ul>";
    $datosClima.="<li>Previsión: ".$tiempo['weather'][0]['description']."</li>";
    $datosClima.="<li>Temperatura media: ".$tiempo['main']['temp']." ºC</li>";
    $datosClima.="<li>Temperatura mínima: ".$tiempo['main']['temp_min']." ºC</li>";
    $datosClima.="<li>Temperatura máxima: ".$tiempo['main']['temp_max']." ºC</li>";
    $datosClima.="<li>Presión: ".$tiempo['main']['pressure']." ºC</li>";
    $datosClima.="<li>Humedad: ".$tiempo['main']['humidity']." ºC</li>";
    $datosClima.="</ul>";
    $resp->assign('resultados', 'innerHTML',$datosClima);//Introducimos en el div resultados, lo guardado en la variable datos clima
    }  
    return $resp;
}

$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'calcularClima');//Registramos la función en Jaxon