<?php
// EXAMEN 3º AVALIACION DWES
session_start(); //Iniciamos la sesión para trabajar con sesiones
require '../vendor/autoload.php';

use Clases\Clases1\ClasesOperacionesService;

//Preparamos Jaxon:
use function Jaxon\jaxon;
require '../src/Clima.php';
if($jaxon->canProcessRequest())  $jaxon->processRequest();//Para procesar la solicitud

//Servicio Soap
$url = 'http://127.0.0.1/EXAMENDWES03/pregunta3/servidorSoap/servicio.wsdl';
try {
    $cliente = new SoapClient($url);
} catch (SoapFault $f) {
    die("Error en cliente SOAP:" . $f->getMessage());
}
$objeto = new ClasesOperacionesService();

//Preparamos los options de los select de cada variable
use Clases\{Producto, Familia, Tienda};
$familia=new Familia();
$familias=$familia->getFamilias();
$familia=null;
$tienda=new Tienda();
$tiendas=$tienda->getTiendas();
$tienda=null;
$producto=new Producto();
$productos=$producto->getProductos();

if(!isset($_GET['enviar'])){//Inicializamos la variables cuando aún no le hemos dado al botón de enviar
    $codT="";
    $codP="";
    $codF="";
    $fecha="";
} else {//Si pulsamos el botón enviar, guardamos los valores seleccionados en las variables
    $codT=$_GET['codT'];
    $codP=$_GET['codP'];
    $codF=$_GET['codF'];
    $fecha=$_GET['fecha'];
    $fechaF=date_create($fecha);//Creamos la fecha
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../js/funciones.js" type="text/javascript"></script>
    <title>Document</title>
</head>
<body>
<div class="container mt-5">
        <div class="d-flex justify-content-center h-100">
            <div class="card">
                <div class="card-header">
                    <h3>Introducir los datos de búsqueda</h3>
                </div>
                <div class="card-body">
                    <form name='datos' method='GET' action='<?php echo $_SERVER['PHP_SELF']; ?>'>
                        <div class="input-group form-group">
                            <label for="codT">Código de Tienda</label>
                            <select id="codT" name="codT" >
                            <?php
                            //El valor predefinido está vacío o se muestra cuando se recarga la página
                            echo "<option value='{$codT}'>{$codT}</option>";
                            //Recorremos el array de ids de tiendas obtenido
                            for($i=0; $i<count($tiendas); $i++) {
                                echo "<option value='{$tiendas[$i]}'>{$tiendas[$i]}</option>";
                                }
                            ?>
                            </select>
                        </div>
                        <div class="input-group form-group">
                            <label for="codP">Código de Producto</label>
                            <select id="codP" name="codP" >
                            <?php
                            //El valor predefinido está vacío o se muestra cuando se recarga la página
                            echo "<option value='{$codP}'>{$codP}</option>";
                            //Recorremos el array de codigos de productos obtenido
                            for($i=0; $i<count($productos); $i++) {
                                $nombreProducto=$producto->getProducto($productos[$i]);//Por cada id obtenemos el nombre del producto
                                echo "<option value='{$nombreProducto}'>{$nombreProducto}</option>";
                                }
                            ?>
                            </select>
                            <p id="errorProducto" style="color:red; display:none;">El producto no existe</p>
                        </div>
                        <div class="input-group form-group">
                            <label for="codF">Código de Familias</label>
                            <select id="codF" name="codF" >
                            <?php
                            //El valor predefinido está vacío o se muestra cuando se recarga la página
                                echo "<option value='{$codF}'>{$codF}</option>";
                            //Recorremos el array de codigos de familias obtenido
                            for($i=0; $i<count($familias); $i++) {
                                echo "<option value='{$familias[$i]}'>{$familias[$i]}</option>";
                                }
                            ?>
                            </select>
                        </div>
                        <div class="input-group form-group">
                            <label for="fecha"></label>
                            <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo $fecha?>">
                        </div>
                        <?php
                        echo"<button class='btn float-right btn-success' id='enviar' name='enviar'>Enviar</button>";
                        if(isset($_GET['enviar'])){
                            if($codP==""){//Si no se ha introducido ningún valor, alertamos
                                echo"<p  style='color:red;'>Debe seleccionar un producto</p>";
                            }  else {
                                echo "<p>Precio de producto $codP ";
                                $codP=$producto->getProductoId($codP);//Para obtener el id del producto a partir de su nombre

                                //funcion getPvp ------------------------------------------------------------------------
                                $pvp = $objeto->getPvp($codP);
                                $precio = ($pvp == null) ? "No existe es Producto" : $pvp;
                                echo "de código $codP: $precio  €</p>";
                            }
                            if($codF==""){
                                echo"<p  style='color:red;'>Debe seleccionar una familia</p>";

                                //funcion getFamilias -------------------------------------------------------------------
                                echo "<br>Los códigos de Familias son:";
                                $prueba = $objeto->getFamilias();
                                echo "<ul>";
                                foreach ($prueba as $k => $v) {
                                   echo "<code><li>$v</li></code>";
                                }
                                echo "</ul>";
                            } else {
                                //funcion getProductosFamila ------------------------------------------------------------
                                $productos = $objeto->getProductosFamilia($codF);
                                echo "Productos de la Famila $codF:";
                                $prueba = $objeto->getProductosFamilia($codF);
                                if($prueba==null){
                                    echo "<p style='color:red;'>No existen productos para esta familia</p>";
                                } else {
                                    echo "<ul>";
                                    foreach ($prueba as $k => $v) {
                                        echo "<code><li>$v</li></code>";
                                    }
                                    echo "</ul>";
                                }
                                
                            }
                            if($fecha==""){
                                echo"<p style='color:red;'>Debe seleccionar una fecha</p>";
                            }else {
                                echo"<p>La fecha seleccionada es $fecha</p>";
                            }
                            if($codP!="" &&  $codT!=""){//Si se han introducido valores de producto y tienda

                                // funcion getStock ---------------------------------------------------------------------
                                $unidades = $objeto->getStock($codP, $codT);
                                echo "<br>Unidades del producto en la tienda  $codT: $unidades unidades";
                            }  
                            if($codT==""){
                            echo"<p  style='color:red;'>Debe seleccionar una tienda</p>";
                            } else {//Si se ha seleccionado una tienda, imprimimos (fera del form) la ciudad de la tienda y añadimos un botón para consulta asíncrona por ajax
                            
                        }
                        ?>
                    </form>
                        <?php

                        //función getCiudad ---------------------------------------------------------------
                        $ciudad = $objeto->getCiudad($codT);
                        echo "<p>La tienda $codT se situa en la ciudad $ciudad</p>";
                        //En el boton clima asociamos un evento Js que llamará a la función Jaxon registrada pasando por parámtero el nombre de la ciudad
                        //Para que no se recargue el form tras la consulta ajax ponemos el botón del evento fuera del form
                        echo"<div id='resultados'></div>";
                        echo"<button  id='clima' onclick=\"enviarCiudad('{$ciudad}')\">Clima en $ciudad</button>";
                        }
                        ?>
                </div>
            </div>
        </div>
</body>
<?php
    $jaxon = jaxon();
    echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n";
?>
</html>
