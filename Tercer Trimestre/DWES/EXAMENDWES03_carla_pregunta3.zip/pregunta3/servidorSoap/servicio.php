<?php
// EXAMEN 3º AVALIACION DWES

require '../vendor/autoload.php';

$uri = "http://127.0.0.1/EXAMENDWES03/pregunta3/servidorSoap";//Aquí ponemos la uri
$parametros = ['uri' => $uri];

try {
    $server = new SoapServer(NULL, $parametros);//Instanciamos un nuevo servidor soap sin url y con segundo parámtero que es la uri
    //
    $server->setClass('Clases\Operaciones');
    //ofrecerá las funciones implementadas en "src/Operaciones.php"
    $server->handle();
} catch (SoapFault $f) {
    die("error en server: " . $f->getMessage());
}
