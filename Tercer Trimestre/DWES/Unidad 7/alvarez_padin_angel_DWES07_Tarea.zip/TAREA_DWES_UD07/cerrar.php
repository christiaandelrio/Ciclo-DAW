<?php
// Iguar que en las tareas del anterior trimestre, trabajamos con la sesion activa pa cerrarla y mandarnos al login para que nos validemos

session_start();

// Hacemos 'unset' de la sesión activa, y con el 'header' mandamos a la página del login
if (isset($_SESSION['usu'])) {
    unset($_SESSION['usu']);
}

header('Location:login.php');
