<?php
// 1) Hacemos un inicio de sesión
session_start();

// 2) Si no tenemos sesión iniciada con algún usuario, mandamos a la página del login para autenticarnos
if (!isset($_SESSION['usu'])) {
    header('Location:login.php');
    die();
}

// 3) Definimos una variable para guardar nuestro usuario activo
$usu = $_SESSION['usu'];

// 4) Hacemos uso de la autocarga de clases, teniendo cuidado con las rutas
spl_autoload_register(function ($clase) {
    include "./include/" . $clase . ".php";
});

// 5) Hacemos el require de nuestro fichero donde están las funciones de votar
require (__DIR__ . '/votar.php');

// 6) Preparamos Jaxon:
use function Jaxon\jaxon;

// 7) Creamos objeto de la clase Producto
$productos = new Producto();

// 8) LLamamos al método 'listadoProductos', que devuelve una variable $stmt
$todos = $productos->listadoProductos();

// 9) Liberamos la memoria ocupada por el objeto 'Producto'
$productos = null;

// 10) Definimos la función con la que vamos a pintar las estrellas
function pintarEstrellasPagina($p)  {
    // 11) Creamos objeto de la clase Voto
    $votos = new Voto();
    // 12) Invocamos metodo 'getMedia()', pa saber la media de las puntuaciones. Le pasamos parámetro $p pa indicar en qué producto obtenemos la media
    $c = $votos->getMedia($p);
    // 13) Usamos el método 'intval()' para obtener el valor entero de la variable, Y DESCARTAR CUALQUIER PARTE DECIMAL
    $en = intval($c);
    // 14) Calculamos la parte decimal de la variable $c
    $dec = $c - $en;
    // 15) En la variable $estrellas definimos el texto a mostrar con el total de votos para ese producto
    $estrellas = "{$votos->getTotalVotos($p)} Valoraciones. ";
    // 16) Si la variable con el valor entero es mayor de cero, se ejecuta el bloque condicional
    if ($en > 0) {
        // 17) Iteramos desde uno hasta la variable $en, agregando en cada iteración una estrella completa al código HTML
        for ($i = 1; $i <= $en; $i++) {
            $estrellas .= "<i class='fas fa-star'></i>";
        }
        // 18) Si la variable con la parte decimal es igual o mayor a 0.5, agregamos una media estrella al código HTML
        if ($dec >= 0.5)
            $estrellas .= "<i class='fas fa-star-half-alt'></i>";
    } else {
        // 19) Si la variable $en no es mayor que cero, añadimos el texto correspondiente
        $estrellas = "Sin valorar";
    }
    // 20) Asignamos null a la variable para liberar la memoria ocupada por el objeto 'Voto'
    $votos = null;
    // 21) Retornamos el valor de la variable que almacena las estrellas totales
    return $estrellas;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Productos</title>
    <script type="text/javascript" src="votar.js"></script>
</head>

<body style="background:#00bfa5;">
    <div class="float float-right d-inline-flex mt-2">
        <i class="fas fa-user mr-3 fa-2x"></i>
        <!-- Mostramos nuestro usuario en la esquina superior derecha-->
        <input type="text" size='10px' value="<?php echo $usu; ?>" class="form-control mr-2 bg-transparent text-white font-weight-bold" disabled>
        <!-- Botón de cerrar sesión del usuario-->
        <a href="cerrar.php" class="btn btn-warning mr-2">Salir</a>
    </div>
    <br>
    <h4 class="container text-center mt-4 font-weight-bold">Productos onLine</h4>
    <div class="container mt-3">
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th scope="col" class='text-center'>Código</th>
                    <th scope="col" class='text-center'>Nombre</th>
                    <th scope="col" class='text-center'>Valoración</th>
                    <th scpope="col" colspan="2" class='text-center'>Valorar</th>
                </tr>
            </thead>
            <tbody>
                <!-- 22) Pa mostrar los productos, metemos codigo PHP-->
                <?php
                // 23) Hacemos el fetch de la variable $stmt que devuelve el método 'listadoProductos' de la clase 'Producto'
                while ($item = $todos->fetch(PDO::FETCH_OBJ)) {
                    echo "<tr class='text-center'>\n";
                    echo "<th scope='row'>{$item->id}</th>\n";
                    echo "<td>{$item->nombre}</td>\n";
                    echo "<td><div id='votos_{$item->id}' class='float-left'>";
                    // 24) Invocamos al método para poder pintar las estrellas y reflejarlas en la página, pasándole el id del producto
                    echo pintarEstrellasPagina($item->id);
                    echo "</div> </td>\n";
                    echo "<td><select name='puntos' class='form-control' id='spuntos_{$item->id}'>";
                    // 25) Con un bucle for recorremos desde 1 hasta 5 para poder mostrar las estrellas
                    for ($i = 1; $i <= 5; $i++) {
                        echo "<option>$i</option>\n";
                    }
                    echo "</select>\n";
                    echo "</td><td>";
                    // 26) Invocamos el método 'envVoto' que utilizará la función 'Jaxon_miVoto', asignada al evento 'onClick'
                    echo "<button class='btn btn-info' onclick=\"envVoto('{$usu}','{$item->id}')\">Votar</button>";
                    echo "</td>\n";
                    echo "</tr>\n";
                }
                ?>
            </tbody>
        </table>
</body>
<?php
// 27) Inyectamos los scripts javascript antes de enviar la página:
$jaxon = jaxon();
echo $jaxon->getCss(), "\n", $jaxon->getJs(), "\n", $jaxon->getScript(), "\n";
echo "<!-- HTTP comment  -->\n"
?>
</html>
