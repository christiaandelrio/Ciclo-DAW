// En este ejemplo, utilizamos las LLAMADAS SÍNCRONAS, en las cuales la página web ESPERA por la respuesta de la petición AJAX
// En el otro ejemplo, usamos las llamadas ASÍNCRONAS, donde tras llamar a la función, el procesamiento del formulario CONTINUA SIN ESPERAR RESPUESTA

// Función a la que llamamos en el formulario
function envForm() {
    // Vamos a llamar a la función 'vUsuario' de validar.php, y necesitamos pasarle los parámetros, q obtenemos pinchandolos con GetId
    let usu = document.getElementById("usu").value;
    let pass = document.getElementById('pass').value;

    // llamamos por AJAX al php y le pasamos los parámetros:
    jaxon_vUsuario(usu, pass);
    
    // anulamos la acción por defecto del formulario:
    return false;
}

// Si valida, mandamos al listado
function validado() {
    window.open("listado.php", "_self");
}
// Si no valida, sacamos un mensaje de alerta
function noValidado() {
    alert("¡¡¡Usuario o contraseña no válidos!!!");
}