<?php

// Hacemos los require necesarios
require (__DIR__ . '/include/Voto.php');
require (__DIR__ . '/vendor/autoload.php');

// Declaramos los namespaces
use Jaxon\Jaxon;
use function Jaxon\jaxon;

// Definimos la función
function miVoto($u, $p, $c) {
    //  Usamos método 'newResponse' porque retornamos una respuesta
    $resp = jaxon()->newResponse();
    // Comprobaciones
    if (strlen($u) == 0 || strlen($p) == 0) {
        $resp->alert("Ni el usuario ni el producto pueden estar vacíos!!!");
    } else {
        // Creamos objeto de la clase 'Voto'
        $voto = new Voto();
        // Usamos la sentencia 'if' con el método 'puedeVotar', para verificar si ese usuario puede votar
        if ($voto->puedeVotar($u, $p)) {
            // Asignamos datos al objeto voto, usando los setters
            $voto->setIdPr($p);
            $voto->setIdUs($u);
            $voto->setCantidad($c);
            // Creación y almacenamiento del voto en la base de datos
            $voto->create();
            // Usando AJAX (a través de Jaxon), invocamos el método javascript votoValido, y le pasamos los datosRespuesta
            $datosRespuesta = array( 'pro' => $p, 'media' => $voto->getMedia($p));
            // Realizamos la llamada
            $resp->call('votoValido', $datosRespuesta);
        } else {
            // Si el método 'puedeVotar' resulta en false, mostramos una alerta
            $resp->alert("Ya has votado ese producto !!!");
        }
        // Liberamos la memoria utilizada
        $voto = null;
    }
    // Retornamos la respuesta
    return $resp;
}

// Definimos ahora la función de pintar Estrellas
function pintarEstrellas($c, $p) {
    // Creamos nuevamente objeto de la clase voto
    $voto = new Voto();
    // Obtenemos el total de votos recibidos por un producto
    $total = $voto->getTotalVotos($p);
    // Liberamos memoria
    $voto = null;
    // Usamos método 'newResponse' porque retornamos una respuesta
    $resp = jaxon()->newResponse();
    // Usamos método intval para obtener el entero
    $en = intval($c);
    // Calculamos la parte decimal
    $dec = $c - $en;
    // El total de valoraciones recibidas por eso producto
    $estrellas = "$total Valoraciones. ";
    // Iteramos para obtener las estrellas a pintar
    if ($en > 0) {
        for ($i = 1; $i <= $en; $i++) {
            $estrellas .= "<i class='fas fa-star'></i>";
        }
        if ($dec >= 0.5)
            $estrellas .= "<i class='fas fa-star-half-alt'></i>";
    }
    // Usamos el método 'assign' para asignar el contenido HTML de la variable $estrellas al elemento de id 'votos_$p'
    $resp->assign("votos_$p", "innerHTML", $estrellas);
    // Retornamos la respuesta
    return $resp;
}

// Creamos el objeto jaxon 
$jaxon = jaxon();

// Registramos las funciones que vamos a llamar desde JavaScript
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'miVoto');
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'pintarEstrellas');

// Procesar la solicitud
if($jaxon->canProcessRequest())  $jaxon->processRequest();

?>
