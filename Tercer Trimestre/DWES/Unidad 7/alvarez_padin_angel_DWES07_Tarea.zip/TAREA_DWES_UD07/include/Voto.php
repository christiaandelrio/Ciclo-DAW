<?php


class Voto extends Conexion {
    public $id;
    public $cantidad;
    public $idPr;
    public $idUs;

    public function __construc() {
        parent::__construct();
    }

    /**
     * @param mixed $cantidad
     */
    public function setCantidad($cantidad): void  {
        $this->cantidad = $cantidad;
    }

    /**
     * @param mixed $idPr
     */
    public function setIdPr($idPr): void {
        $this->idPr = $idPr;
    }

    /**
     * @param mixed $idUs
     */
    public function setIdUs($idUs): void {
        $this->idUs = $idUs;
    }
    
    // Método para insertar nuevos votos a la base de datos
    public function create() {
        $i = "insert into votos(cantidad, idPr, idUs) values(:c, :ip, :iu)";
        $stmt = $this->conexion->prepare($i);

        try {
            $stmt->execute([
                ':c'  => $this->cantidad,
                ':ip' => $this->idPr,
                ':iu' => $this->idUs
            ]);
        } catch (PDOException $ex) {
            die("Error al guardar voto: " . $ex->getMessage());
        }
    }
    
    // Método para obtener el total de puntos de un producto concreto
    public function getTotalPuntos($p) {
        $c    = "select sum(cantidad) as total from votos where idPr=:p";
        $stmt = $this->conexion->prepare($c);

        $stmt->execute([':p' => $p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->total;
    }

    // Método para obtener el total de votos que ha recibido un producto concreto
    public function getTotalVotos($p) {
        $c    = "select count(*) as total from votos where idPr=:p";
        $stmt = $this->conexion->prepare($c);

        $stmt->execute([':p'=>$p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->total;
    }

    // Método para obtener la media de valoración que ha recibido un producto concreto
    public function getMedia($p) {
        $c    = "select avg(cantidad) as media from votos where idPr=:p";
        $stmt = $this->conexion->prepare($c);

        $stmt->execute([':p' => $p]);
        return ($stmt->fetch(PDO::FETCH_OBJ))->media;
    }

    // Método para comprobar si un usuario ya ha valorado (votado) un determinado producto
    public function puedeVotar($u, $p)  {
        $c    = "select * from votos where idPr=:p AND idUs=:u";
        $stmt = $this->conexion->prepare($c);

        $stmt->execute([':p' => $p, ':u' => $u]);
        
        $filas = $stmt->rowCount();
        if ($filas == 0) return true;
        return false;
    }
}
