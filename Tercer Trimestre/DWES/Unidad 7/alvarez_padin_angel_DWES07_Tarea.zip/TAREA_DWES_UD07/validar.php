<?php

require (__DIR__ . '/include/Conexion.php');
require (__DIR__ . '/include/Usuario.php');
require (__DIR__ . '/vendor/autoload.php');

// Declaramos los namespaces
use Jaxon\Jaxon;
use function Jaxon\jaxon;

// Definimos la funcion
function vUsuario($u, $p)  {
    //  Creamos objeto 'newResponse' porque retornamos una respuesta
    $resp = jaxon()->newResponse();
    // Comprobación de si los campos están vacios
    if (strlen($u) == 0 || strlen($p) == 0) {
        // *** OJOOO*** Con el método 'call' LLAMAMOS A LAS FUNCIONES DE JAVASCRIPT, en validar.js
        $resp->call('noValidado');
    } else {    // comprobar en base de datos si existe el usuario
        $usuario = new Usuario();
        if (!$usuario->isValido($u, $p)) {
            $resp->call('noValidado');
        } else {
            session_start();
            $_SESSION['usu'] = $u;
            $resp->call('validado');
        }
        $usuario = null;
    }
    // Retornamos la respuesta
    return $resp;
}

// Creamos el objeto jaxon 
$jaxon = jaxon();

// Opciones de configuración Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);
$jaxon->setOption('core.debug.verbose', false);

// Registramos la funcion q vamos a llamar desde JavaScript
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'vUsuario');

// El método processRequest procesa las peticiones que llegan a la página
if($jaxon->canProcessRequest())  $jaxon->processRequest();


?>
