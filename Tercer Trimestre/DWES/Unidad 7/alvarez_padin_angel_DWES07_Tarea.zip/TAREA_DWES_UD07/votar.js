function envVoto(usu, pro) {
    // Obtenemos los parametros para poder pasarle a la función
    id = "spuntos_" + pro;
    var puntos = document.getElementById(id).value;
    // Llamamos al php y le pasamos los parámetros
    jaxon_miVoto(usu, pro, puntos);
}

// Función a la que llamamos desde el fichero 'votar.php'
function votoValido(datos) {
    // Llamamos nuevamente al php y le pasamos los parámetros obtenidos de la variable $datosRespuesta al hacer el 'call' de esta funcion en el php
    jaxon_pintarEstrellas(datos['media'], datos['pro']);
}