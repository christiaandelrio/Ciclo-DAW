<?php

session_start();

//Eliminamos al usuario de la sesión
if (isset($_SESSION['usu'])) unset($_SESSION['usu']);

//Redirigimos al usuario a la página de login
header('Location:login.php');
