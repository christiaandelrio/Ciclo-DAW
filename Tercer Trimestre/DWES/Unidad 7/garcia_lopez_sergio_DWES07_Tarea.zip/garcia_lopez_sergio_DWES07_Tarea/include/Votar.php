<?php
// [JAXON-PHP]
//Se define una función de autoloading para cargar automáticamente las clases
spl_autoload_register(function ($clase) {
    include $clase . ".php";
});

require (__DIR__ . '/../vendor/autoload.php');

//Importamos las clases necesarias
use Jaxon\Jaxon;
use function Jaxon\jaxon;

//Creamos el objeto jaxon
$jaxon = jaxon();

//Definimos la función miVoto: se ejecutará cuando se realice una acción de voto. Toma tres parámetros: $u, $p, y $c. La función crea una respuesta de Jaxon y realiza algunas validaciones y operaciones relacionadas con el voto. Dependiendo de las condiciones, se envía una llamada AJAX a una función JavaScript llamada votoValido pasando algunos datos.
function miVoto($u, $p, $c) {
    //Creamos la respuesta Jaxon
    $resp = jaxon()->newResponse();

    //Validamos que el usuario y el producto no estén vacíos
    if (strlen($u) == 0 || strlen($p) == 0) {
        $resp->alert("Ni el usuario ni el producto pueden estar vacíos!!!");
    } else {
        //Creamos un objeto Voto
        $voto = new Voto();
        
        //Si el usuario puede votar (no ha votado previamente), se crea el voto con los datos recibidos
        if ($voto->puedeVotar($u, $p)) {
            $voto->setIdPr($p);
            $voto->setIdUs($u);
            $voto->setCantidad($c);
            $voto->create();
            
            // Usando AJAX (a través de Jaxon), invocamos el método javascript votoValido
            $datosRespuesta = array( 'pro' => $p, 'media' => $voto->getMedia($p));
            $resp->call('votoValido', $datosRespuesta);
        } else {
            //Si el usuario ya ha votado ese producto, se muestra un mensaje de error
            $resp->alert("Ya has votado ese producto !!!");
        }

        //Liberamos el objeto Voto
        $voto = null;
    }

    //Retornamos la respuesta
    return $resp;
}

//Función para dibujar estrellas al lado del producto según el voto
function pintarEstrellas($c, $p) {
    $voto      = new Voto();
    //Obtenemos el total de votos del producto
    $total     = $voto->getTotalVotos($p);
    $voto      = null;

    //Creamos la respuesta Jaxon
    $resp      = jaxon()->newResponse();
    $en        = intval($c);
    $dec       = $c - $en;
    //Creamos un string con el total de votos y las estrellas correspondientes
    $estrellas = "$total Valoraciones. ";

    //Dibujamos las estrellas
    if ($en > 0) {
        for ($i = 1; $i <= $en; $i++) {
            $estrellas .= "<i class='fas fa-star'></i>";
        }
        if ($dec >= 0.5)
            $estrellas .= "<i class='fas fa-star-half-alt'></i>";
    }

    //Creamos la respuesta
    $resp->assign("votos_$p", "innerHTML", $estrellas);
    
    //Retornamos la respuesta
    return $resp;
}

//Registramos las funciones que vamos a poder usar desde el cliente
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'miVoto');
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'pintarEstrellas');

