<?php
// [JAXON-PHP]
//validar.php configura Jaxon-PHP, define una función para validar un usuario y una contraseña, y registra esta función para ser llamada mediante AJAX.

//Importamos la conexión a base de datos
require 'Conexion.php';
//Importamos la calse Usuario
require 'Usuario.php';

require (__DIR__ . '/../vendor/autoload.php');

//Importamos Jaxon
use Jaxon\Jaxon;
use function Jaxon\jaxon;

//Creamos una instancia de Jaxon
$jaxon = jaxon();

// Opciones de configuración Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);
$jaxon->setOption('core.debug.verbose', false);

//Función de validación de usuario
function vUsuario($u, $p)  {
    //Llamamos al método newResponse de Jaxon, que se asigna a la variable $resp, que se utiliza para construir la respuesta que será devuelta al cliente.
    $resp = jaxon()->newResponse();
    

    //Si el usuario o la contraseña están vacíos, llamamos a la función noValidado de validar.js
    if (strlen($u) == 0 || strlen($p) == 0) {
        $resp->call('noValidado');
    } else {
        //Si pasamos la validación creamos un usuario. Creamos una instancia de Usuario
        $usuario = new Usuario();

        //Hacemos la validación propia de la clase Usuario. Si falla llamamos a la función noValidado de validar.js.
        //FIXME: No me pasa esta validación
        if (!$usuario->isValido($u, $p)) {
            $resp->call('noValidado');
        } else {
            
            //Si pasamos todas las validaciones, creamos una sesión de usuario a la que le pasamos el nombre del usuario creado
            session_start();
            $_SESSION['usu'] = $u;
            //Llamamos a la función validado de validar.js
            $resp->call('validado');
        }
        //Reseteamos la variable $usuario
        $usuario = null;
    }

    //Devolvemos la respuesta
    return $resp;
}

//El método register() permite registrar cada una de las funciones PHP del servidor que estarán disponibles para ser ejecutadas de forma asíncrona desde el navegador. En nuestro caso, registraremos la función vUsuario, que es una función de validación, que podrá ser llamada mediante AJAX desde el cliente.
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'vUsuario');

/* 
Al registrar una función con register(), se crea automáticamente una función JavaScript en el documento HTML con su mismo nombre prefijado por "jaxon_".
En el caso anterior, se creará la función jaxon_vUsuario. Vamosa  emplear esta función en validar.js.
*/
