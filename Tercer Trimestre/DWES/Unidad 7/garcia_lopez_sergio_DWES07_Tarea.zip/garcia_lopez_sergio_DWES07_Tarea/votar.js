// [JAXON-PHP]
//votar.js es el archivo que contiene las funciones que se ejecutarán desde el cliente. Va a hacer uso de las funciones definidas en Votar.php, pintarEstrellas() y miVoto().
function envVoto(usu, pro) {
	id = 'spuntos_' + pro;
	var puntos = document.getElementById(id).value;

	jaxon_miVoto(usu, pro, puntos);
}

function votoValido(datos) {
	jaxon_pintarEstrellas(datos['media'], datos['pro']);
}
