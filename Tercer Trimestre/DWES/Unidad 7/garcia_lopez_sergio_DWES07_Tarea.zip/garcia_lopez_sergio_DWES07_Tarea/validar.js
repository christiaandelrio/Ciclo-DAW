// [JAXON-PHP]
// La función envForm() es un manejador de eventos que se ejecuta cuando se envía un formulario. Se utiliza para obtener los valores de los campos de usuario y contraseña del formulario (identificados por los IDs 'usu' y 'pass' respectivamente) y luego llama a la función jaxon_vUsuario() pasando esos valores como argumentos
function envForm() {
	let usu = document.getElementById('usu').value;
	let pass = document.getElementById('pass').value;

	//jaxon_vUsuario es una función que Jaxon crea automáticamente una vez que se hace uso del método $jaxon->register(). En nuestro caso, jaxon_vUsuario, la hemos obtenido en Validar.php al crear el registro $jaxon->register(Jaxon::CALLABLE_FUNCTION, 'vUsuario');
	jaxon_vUsuario(usu, pass);

	//Anulamos la acción por defecto del formulario:
	return false;
}

//Si se cumple la validación redirigimos a la página de listado.php
function validado() {
	window.open('listado.php', '_self');
	// alert('Usuario validado');
}

//Si no se cumple la validación mostramos una alerta con error
function noValidado() {
	alert('¡¡Usuario o contraseña no válidos!!!');
}
