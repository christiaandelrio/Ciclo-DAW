// [JAXON-PHP]
//En esta archivo se crea la función javascript que se encargará de gestionar el envio de votos mediante la funcion php miVoto y votoValido
function envVoto(usu, pro) {
    id = "spuntos_" + pro;
    var puntos = document.getElementById(id).value;
    
    jaxon_miVoto(usu, pro, puntos);
}

function votoValido(datos) {
    jaxon_pintarEstrellas(datos['media'], datos['pro']);
}