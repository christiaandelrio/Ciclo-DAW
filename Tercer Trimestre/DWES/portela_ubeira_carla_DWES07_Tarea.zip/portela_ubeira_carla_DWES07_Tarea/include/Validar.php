<?php
// [JAXON-PHP]
require 'Conexion.php'; //Incluye la página que inicia la conexión con la db
require 'Usuario.php'; //Incluye la página con la clase usuario y su funcionalidad
require (__DIR__ . '/../vendor/autoload.php');

use Jaxon\Jaxon;
use function Jaxon\jaxon;

$jaxon = jaxon(); //Instanciamos un objeto de la clase jaxon mediante su constructor

//Configuramos Jaxon mediante los métodos de la clase Jaxon: 
$jaxon->setOption('js.app.minify', false);
$jaxon->setOption('core.decode_utf8', true);
$jaxon->setOption('core.debug.on', false);//Desactivamos los mensajes de depuración
$jaxon->setOption('core.debug.verbose', false);

//Creamos la función php que realizará la validación del usuario, llamando a las funciones Javascript
function vUsuario($u, $p)  {
    
    $resp = jaxon()->newResponse(); //En cada una de las funciones definidas, se instancia un objeto para devolver el resultado del procedimiento
    if (strlen($u) == 0 || strlen($p) == 0) {//Si el usuario o la contraseña tienen un tamaño de 0, llama a la funcion de Javascript para lanzar el mensaje correspondiente
        $resp->call('noValidado');
    } else {
        $usuario = new Usuario();//Sino crea un nuevo objeto de la clase Usuario 
        if (!$usuario->isValido($u, $p)) {//Mediante el método de clase isValido, pasamos como parámetros el usuario y la contraseña, y si el resultado es false,
            $resp->call('noValidado');//llamamaos a la función de Javascript para que alerte mediante un mensaje y redirija al usuario a login.php
        } else {
            session_start();//Pero si el usuario y contraseña son válidos, iniciamos la sesión del usuario
            $_SESSION['usu'] = $u;
            $resp->call('validado');//Llamamos a la función de Javascript para que redirija al usuario a la página listado.php
        }
        $usuario = null;//Tras lo cual, vaciamos la variable usuario establecéndola en null
    }

    return $resp;//La función devuelve la variable respuesta, que es un booleano(true o false)
}

//Por último, se regristra cada una de las funciones php que estarán disponibles para ejecutarse de forma asíncrona, mediante el método register()
$jaxon->register(Jaxon::CALLABLE_FUNCTION, 'vUsuario');
